import { afterAll, afterEach, describe, expect, it } from "vitest";
import { mkdtempSync, rmSync, writeFileSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { transcribeWithOpenAI } from "../../src/backends/openai.js";
import { parseAudioEventsResponse } from "../../src/backends/openai-audio-events.js";
import { mapTranscriptionResponse } from "../../src/backends/openai.js";
import { analyzeFramesWithOpenAI } from "../../src/backends/openai-vision.js";

describe("OpenAI adapter response validation", () => {
  it("parses valid non-speech sound events", () => {
    expect(parseAudioEventsResponse('{"audio_tags":[{"start":"00:00:01","end":"00:00:03","tag":"ambient music"}]}')).toEqual([
      { start: "00:00:01", end: "00:00:03", tag: "ambient music" },
    ]);
  });

  it("rejects malformed timestamps instead of inventing values", () => {
    expect(() => parseAudioEventsResponse('{"audio_tags":[{"start":"bad","end":"00:00:03","tag":"noise"}]}')).toThrow();
  });

  it("rejects events whose end precedes the start", () => {
    expect(() => parseAudioEventsResponse('{"audio_tags":[{"start":"00:00:04","end":"00:00:03","tag":"noise"}]}')).toThrow();
  });
});


describe("OpenAI transcription timing contract", () => {
  it("does not invent timestamps for gpt-transcribe text output", () => {
    const result = mapTranscriptionResponse({ text: "Olá, mundo." }, "gpt-transcribe");
    expect(result.transcription_timing).toBe("unavailable");
    expect(result.transcription).toEqual([{ start: "00:00:00", end: "00:00:00", text: "Olá, mundo." }]);
  });

  it("keeps measured whisper segment offsets with milliseconds", () => {
    const result = mapTranscriptionResponse({ segments: [{ start: 1.25, end: 2.5, text: " fala " }] }, "whisper-1", 10);
    expect(result.transcription_timing).toBe("measured");
    expect(result.transcription).toEqual([{ start: "00:00:11.250", end: "00:00:12.500", text: "fala" }]);
  });
});


describe("OpenAI Vision adapter (mocked transport)", () => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.OPENAI_API_KEY;

  afterEach(() => {
    globalThis.fetch = originalFetch;
    if (originalKey === undefined) delete process.env.OPENAI_API_KEY;
    else process.env.OPENAI_API_KEY = originalKey;
  });

  it("requires an API key and does not attempt a request without one", async () => {
    delete process.env.OPENAI_API_KEY;
    await expect(analyzeFramesWithOpenAI([{ timestamp: "00:00:01", image: "aGVsbG8=", format: "jpeg" }])).rejects.toThrow(/OPENAI_API_KEY/);
  });

  it("sends timestamped still images to Responses API and parses a structured result", async () => {
    process.env.OPENAI_API_KEY = "test-key-not-real";
    let requestBody: any;
    globalThis.fetch = async (_input: any, init?: any) => {
      requestBody = JSON.parse(init.body);
      return new Response(JSON.stringify({
        model: "gpt-6.1-terra",
        output: [{ content: [{ type: "output_text", text: JSON.stringify({
          summary: "A pessoa atravessa o quadro.",
          frames: [{ timestamp: "00:00:01.000", description: "Uma pessoa aparece.", observed_changes: ["posição mudou"], confidence_notes: [] }],
          limitations: ["A análise usa quadros amostrados."],
        }) }] }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };

    const result = await analyzeFramesWithOpenAI([
      { timestamp: "00:00:01.000", image: "aGVsbG8=", format: "jpeg" },
    ], { model: "gpt-6.1-terra", detail: "low", maxFrames: 12 });

    expect(requestBody.model).toBe("gpt-6.1-terra");
    expect(requestBody.input[0].content.some((part: any) => part.type === "input_image" && part.image_url.startsWith("data:image/jpeg;base64,"))).toBe(true);
    expect(result.frames[0].timestamp).toBe("00:00:01.000");
    expect(result.summary).toContain("atravessa");
  });
});


describe("OpenAI transcription adapter (mocked transport)", () => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.OPENAI_API_KEY;
  const originalModel = process.env.OPENAI_TRANSCRIPTION_MODEL;
  const work = mkdtempSync(join(tmpdir(), "cvv-openai-adapter-test-"));
  const wav = join(work, "sample.wav");
  writeFileSync(wav, Buffer.from("not-a-real-wav; transport is mocked"));

  afterEach(() => {
    globalThis.fetch = originalFetch;
    if (originalKey === undefined) delete process.env.OPENAI_API_KEY;
    else process.env.OPENAI_API_KEY = originalKey;
    if (originalModel === undefined) delete process.env.OPENAI_TRANSCRIPTION_MODEL;
    else process.env.OPENAI_TRANSCRIPTION_MODEL = originalModel;
  });

  it("uses gpt-transcribe and marks unavailable timestamps honestly", async () => {
    process.env.OPENAI_API_KEY = "test-key-not-real";
    delete process.env.OPENAI_TRANSCRIPTION_MODEL;
    globalThis.fetch = async (_input: any, init?: any) => {
      expect(init.body.get("model")).toBe("gpt-transcribe");
      return new Response(JSON.stringify({ text: "Fala de teste." }), { status: 200 });
    };
    const result = await transcribeWithOpenAI(wav);
    expect(result.transcription_timing).toBe("unavailable");
    expect(result.transcription[0].text).toBe("Fala de teste.");
    expect(result.warnings?.some((item) => item.detail?.includes("timestamps were not fabricated"))).toBe(true);
  });

  it("uses whisper-1 verbose segments with measured timestamps when selected", async () => {
    process.env.OPENAI_API_KEY = "test-key-not-real";
    process.env.OPENAI_TRANSCRIPTION_MODEL = "whisper-1";
    globalThis.fetch = async (_input: any, init?: any) => {
      expect(init.body.get("response_format")).toBe("verbose_json");
      expect(init.body.get("timestamp_granularities[]")).toBe("segment");
      return new Response(JSON.stringify({ segments: [{ start: 0.25, end: 1.5, text: " Olá " }] }), { status: 200 });
    };
    const result = await transcribeWithOpenAI(wav);
    expect(result.transcription_timing).toBe("measured");
    expect(result.transcription[0]).toEqual({ start: "00:00:00.250", end: "00:00:01.500", text: "Olá" });
  });

  afterAll(() => rmSync(work, { recursive: true, force: true }));
});
