import { describe, expect, it } from "vitest";
import { formatHMSPrecise, parseHMS } from "../../src/utils/timestamps.js";

describe("sub-second timestamp precision", () => {
  it("formats fractional seconds without collapsing adjacent frames", () => {
    expect(formatHMSPrecise(0.5)).toBe("00:00:00.500");
    expect(formatHMSPrecise(1.5)).toBe("00:00:01.500");
  });
  it("keeps whole-second legacy timestamps unchanged", () => {
    expect(formatHMSPrecise(2)).toBe("00:00:02");
  });
  it("parses timestamps with milliseconds", () => {
    expect(parseHMS("00:00:01.500")).toBe(1.5);
  });
});
