import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { mkdtempSync, rmSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { fileURLToPath } from "url";

const FIXTURE = fileURLToPath(new URL("../fixtures/test-3s.mp4", import.meta.url));
const TEST_HOME = mkdtempSync(join(tmpdir(), "cvv-six-tools-"));

let handlers: Map<string, (...args: any[]) => Promise<any>>;
let register: Record<string, (server: any) => void>;

function fakeServer() {
  handlers = new Map();
  return {
    tool(name: string, _description: string, _schema: unknown, handler: (...args: any[]) => Promise<any>) {
      handlers.set(name, handler);
    },
  };
}

describe("six original MCP tool handlers (real local media)", () => {
  beforeAll(async () => {
    process.env.VIDEO_VISION_HOME = TEST_HOME;
    delete process.env.OPENAI_API_KEY;
    delete process.env.GEMINI_API_KEY;
    const [watch, analyze, detail, info, configure, setup] = await Promise.all([
      import("../../src/tools/video-watch.js"),
      import("../../src/tools/video-analyze.js"),
      import("../../src/tools/video-detail.js"),
      import("../../src/tools/video-info.js"),
      import("../../src/tools/video-configure.js"),
      import("../../src/tools/video-setup.js"),
    ]);
    register = {
      video_watch: watch.registerVideoWatch,
      video_analyze: analyze.registerVideoAnalyze,
      video_detail: detail.registerVideoDetail,
      video_info: info.registerVideoInfo,
      video_configure: configure.registerVideoConfigure,
      video_setup: setup.registerVideoSetup,
    };
  });

  afterAll(() => rmSync(TEST_HOME, { recursive: true, force: true }));

  it("registers all six original tool names", () => {
    const server = fakeServer();
    Object.values(register).forEach((fn) => fn(server));
    expect([...handlers.keys()].sort()).toEqual([
      "video_analyze", "video_configure", "video_detail", "video_info", "video_setup", "video_watch",
    ]);
  });

  it("video_info returns actual FFprobe metadata", async () => {
    const server = fakeServer(); register.video_info(server);
    const result = await handlers.get("video_info")!({ path: FIXTURE });
    const text = result.content.find((part: any) => part.type === "text")?.text || "";
    expect(text).toContain("duration_seconds");
    expect(text).toContain("resolution");
    expect(text).not.toContain("undefined");
  });

  it("video_analyze runs real FFmpeg structural filters", async () => {
    const server = fakeServer(); register.video_analyze(server);
    const result = await handlers.get("video_analyze")!({
      path: FIXTURE,
      filters: { scene_changes: true, black_intervals: true, silence: true, freeze: true, motion: true, blur: false, exposure: false, loudness: true, transcription: false },
    });
    const text = result.content.find((part: any) => part.type === "text")?.text || "";
    expect(text).toContain('"metadata"');
    expect(text).toContain('"analysis"');
    expect(text).not.toContain("incomplete");
  });

  it("video_watch extracts real frames while audio is explicitly skipped", async () => {
    const server = fakeServer(); register.video_watch(server);
    const result = await handlers.get("video_watch")!({
      path: FIXTURE, fps: 1, resolution: 256, frame_mode: "images", frame_format: "jpeg",
      start_time: undefined, end_time: undefined, skip_audio: true, segments: undefined,
      view_sample: 2, visual_analysis: false,
    });
    expect(result.content.some((part: any) => part.type === "image" && typeof part.data === "string" && part.data.length > 20)).toBe(true);
    expect(result.content.some((part: any) => part.type === "text" && part.text.includes("Video Metadata"))).toBe(true);
  });

  it("video_detail extracts a real selected segment", async () => {
    const server = fakeServer(); register.video_detail(server);
    const result = await handlers.get("video_detail")!({
      path: FIXTURE,
      segments: [{ start: "00:00:00", end: "00:00:02", fps: 1, resolution: 256 }],
      view: undefined, view_sample: 2, frame_format: "jpeg", skip_cached: true, visual_analysis: false,
    });
    expect(result.content.some((part: any) => part.type === "image")).toBe(true);
    expect(result.content.some((part: any) => part.type === "text" && part.text.includes("Viewing"))).toBe(true);
  });

  it("video_configure persists supported settings", async () => {
    const server = fakeServer(); register.video_configure(server);
    const result = await handlers.get("video_configure")!({ vision_model: "gpt-6.1-terra", vision_max_frames: 12, vision_detail: "low", clear_sessions: false });
    expect(result.content[0].text).toContain("Configuration saved");
    const { loadConfig } = await import("../../src/config.js");
    const config = loadConfig(join(TEST_HOME, "config.json"));
    expect(config.vision_model).toBe("gpt-6.1-terra");
    expect(config.vision_max_frames).toBe(12);
  });


  it("runs a complete local video workflow through the original tool handlers", async () => {
    const server = fakeServer();
    Object.values(register).forEach((fn) => fn(server));

    await handlers.get("video_configure")!({ enable_index: true, max_frames: 24, frame_resolution: 256, clear_sessions: true });

    const info = await handlers.get("video_info")!({ path: FIXTURE });
    expect(info.content[0].text).toContain("duration_seconds");

    const analysis = await handlers.get("video_analyze")!({
      path: FIXTURE,
      filters: { scene_changes: true, black_intervals: true, silence: true, freeze: true, motion: true, blur: false, exposure: false, loudness: true, transcription: false },
    });
    expect(analysis.content[0].text).toContain('"analysis"');

    const watch = await handlers.get("video_watch")!({
      path: FIXTURE, fps: 2, resolution: 256, frame_mode: "images", frame_format: "jpeg",
      skip_audio: true, segments: undefined, view_sample: 4, visual_analysis: false,
    });
    const images = watch.content.filter((item: any) => item.type === "image");
    expect(images.length).toBeGreaterThan(0);

    const detail = await handlers.get("video_detail")!({
      path: FIXTURE,
      segments: [{ start: "00:00:00", end: "00:00:02", fps: 2, resolution: 256 }],
      view: undefined, view_sample: 4, frame_format: "jpeg", skip_cached: true, visual_analysis: false,
    });
    expect(detail.content.filter((item: any) => item.type === "image").length).toBeGreaterThan(0);
    expect(detail.content.some((item: any) => item.type === "text" && item.text.includes("Viewing"))).toBe(true);
  });

  it("video_setup reports actual server dependencies without requiring API calls", async () => {
    const server = fakeServer(); register.video_setup(server);
    const result = await handlers.get("video_setup")!({ backend: "openai", whisper_engine: "cpp", whisper_model: "auto" });
    expect(result.content[0].text).toContain("Platform Detected");
    expect(result.content[0].text).toMatch(/Status:/);
  });
});
