#!/usr/bin/env node
const major = Number(process.versions.node.split('.')[0]);
if (!Number.isFinite(major) || major < 24) {
  console.error(`ChatGPT Video Vision MCP requires Node.js 24 or newer. Current runtime: ${process.version}.`);
  console.error('Install an official Node.js 24 LTS or 26 release, then rerun npm ci and npm run build.');
  process.exit(1);
}
console.log(`Node.js runtime check passed: ${process.version}`);
