#!/usr/bin/env node
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtemp, rm, stat } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

const SERVER_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PROJECT_DIR = path.dirname(SERVER_DIR);
const ENTRY = path.join(SERVER_DIR, 'dist', 'index.js');
const HOME = await mkdtemp(path.join(os.tmpdir(), 'chatgpt-video-vision-mcp-stdio-'));
const FIXTURE = path.join(HOME, 'visible-audio-fixture.mp4');
const REQUIRED_TOOLS = [
  'video_watch', 'video_analyze', 'video_detail',
  'video_info', 'video_configure', 'video_setup',
].sort();

function resultText(result) {
  return (result.content || []).filter((part) => part.type === 'text').map((part) => part.text).join('\n');
}

async function call(client, name, args) {
  const result = await client.callTool({ name, arguments: args }, undefined, { timeout: 180_000 });
  if (result.isError) throw new Error(`${name} returned isError: ${resultText(result)}`);
  return result;
}

let client;
try {
  assert.equal(Number(process.versions.node.split('.')[0]) >= 24, true, `Node.js 24+ is required; detected ${process.version}`);
  assert.equal((await stat(ENTRY)).isFile(), true, `Compiled MCP entry not found: ${ENTRY}. Run npm run build first.`);

  execFileSync('ffmpeg', [
    '-hide_banner', '-loglevel', 'error', '-y',
    '-f', 'lavfi', '-i', 'testsrc2=size=320x240:rate=25:duration=6',
    '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100:duration=6',
    '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-shortest', '-movflags', '+faststart', FIXTURE,
  ], { stdio: 'inherit' });

  const env = Object.fromEntries(Object.entries(process.env).filter(([, value]) => value !== undefined));
  delete env.OPENAI_API_KEY;
  delete env.GEMINI_API_KEY;
  delete env.MCP_AUTH_TOKEN;
  env.VIDEO_VISION_HOME = HOME;

  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [ENTRY],
    cwd: PROJECT_DIR,
    env,
    stderr: 'inherit',
  });
  client = new Client({ name: 'chatgpt-video-vision-phase4-test', version: '1.0.0' });
  await client.connect(transport);

  // Official tools/list request over the official SDK stdio transport.
  const catalog = await client.listTools();
  const discovered = (catalog.tools || []).map((tool) => tool.name).sort();
  assert.deepEqual(discovered, REQUIRED_TOOLS, 'MCP tools/list must expose the six original tools');
  for (const tool of catalog.tools) {
    assert.equal(typeof tool.inputSchema, 'object', `${tool.name} must publish an input schema`);
    assert.equal(tool.inputSchema.type, 'object', `${tool.name} must publish an object input schema`);
  }

  const configure = await call(client, 'video_configure', {
    enable_index: true,
    max_frames: 24,
    frame_resolution: 256,
    clear_sessions: true,
  });
  assert.match(resultText(configure), /Configuration saved/i);

  const setup = await call(client, 'video_setup', {
    backend: 'openai', whisper_engine: 'cpp', whisper_model: 'auto',
  });
  assert.match(resultText(setup), /Platform Detected|FFmpeg|Status:/i);

  const info = await call(client, 'video_info', { path: FIXTURE });
  assert.match(resultText(info), /duration_seconds/i);
  assert.match(resultText(info), /resolution/i);

  const analysis = await call(client, 'video_analyze', {
    path: FIXTURE,
    filters: {
      scene_changes: true,
      black_intervals: true,
      silence: true,
      freeze: true,
      motion: true,
      blur: false,
      exposure: false,
      loudness: true,
      transcription: false,
    },
  });
  assert.match(resultText(analysis), /"analysis"/);

  const watch = await call(client, 'video_watch', {
    path: FIXTURE,
    fps: 1,
    resolution: 256,
    frame_mode: 'images',
    frame_format: 'jpeg',
    skip_audio: true,
    view_sample: 4,
    visual_analysis: false,
  });
  const watchImages = (watch.content || []).filter((part) => part.type === 'image');
  assert.ok(watchImages.length >= 1, 'video_watch must return at least one extracted frame');

  const detail = await call(client, 'video_detail', {
    path: FIXTURE,
    segments: [{ start: '00:00:01', end: '00:00:04', fps: 2, resolution: 256 }],
    view_sample: 4,
    frame_format: 'jpeg',
    skip_cached: true,
    visual_analysis: false,
  });
  const detailImages = (detail.content || []).filter((part) => part.type === 'image');
  assert.ok(detailImages.length >= 1, 'video_detail must return frames for a selected segment');

  console.log(JSON.stringify({
    status: 'PASS',
    transport: 'official @modelcontextprotocol/sdk StdioClientTransport',
    protocol: 'initialize, tools/list, tools/call',
    tools: discovered,
    fixture: { path: FIXTURE, durationSeconds: 6, visualPattern: 'testsrc2', audio: '440 Hz sine' },
    results: {
      video_configure: 'passed', video_setup: 'passed', video_info: 'passed',
      video_analyze: 'passed', video_watch: `passed (${watchImages.length} images)`,
      video_detail: `passed (${detailImages.length} images)`,
    },
    externalApis: 'not called; API credentials explicitly removed from child environment',
  }, null, 2));
} catch (error) {
  console.error(error?.stack || String(error));
  process.exitCode = 1;
} finally {
  await client?.close().catch(() => undefined);
  await rm(HOME, { recursive: true, force: true });
}
