import { randomUUID, timingSafeEqual } from "crypto";
import type { IncomingMessage, ServerResponse } from "http";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { createVideoVisionMcpServer, initializeVideoVisionStorage } from "./index.js";

interface McpSession {
  server: ReturnType<typeof createVideoVisionMcpServer>;
  transport: StreamableHTTPServerTransport;
  lastUsed: number;
}
const sessions = new Map<string, McpSession>();
const MAX_SESSIONS = 32;
const SESSION_IDLE_MS = 30 * 60_000;

function tokenMatches(expected: string, supplied: string): boolean {
  const a = Buffer.from(expected);
  const b = Buffer.from(supplied);
  return a.length === b.length && timingSafeEqual(a, b);
}

function authFailure(res: ServerResponse, status: number, message: string): void {
  res.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ error: message }));
}

async function closeSession(id: string): Promise<void> {
  const session = sessions.get(id);
  if (!session) return;
  sessions.delete(id);
  await session.transport.close().catch(() => undefined);
  await session.server.close().catch(() => undefined);
}

async function pruneSessions(): Promise<void> {
  const now = Date.now();
  for (const [id, session] of sessions) {
    if (now - session.lastUsed > SESSION_IDLE_MS) await closeSession(id);
  }
}

/** Authenticated, stateful MCP Streamable HTTP handler. Mount at POST/GET/DELETE /mcp. */
export async function handleMcpHttpRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const expectedToken = process.env.MCP_AUTH_TOKEN;
  if (!expectedToken || expectedToken.length < 24 || expectedToken.includes("CHANGE_ME") || /replace|example/i.test(expectedToken)) {
    authFailure(res, 503, "Remote MCP is disabled: configure MCP_AUTH_TOKEN with at least 24 characters.");
    return;
  }
  const authorization = req.headers.authorization ?? "";
  const supplied = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
  if (!tokenMatches(expectedToken, supplied)) {
    authFailure(res, 401, "Unauthorized");
    return;
  }

  await pruneSessions();
  initializeVideoVisionStorage();
  const sessionId = req.headers["mcp-session-id"] as string | undefined;
  let session = sessionId ? sessions.get(sessionId) : undefined;

  if (sessionId && !session) {
    authFailure(res, 404, "MCP session not found or expired.");
    return;
  }

  if (!session && req.method !== "POST") {
    authFailure(res, 400, "A new MCP session must begin with POST initialize.");
    return;
  }

  if (!session) {
    if (sessions.size >= MAX_SESSIONS) {
      authFailure(res, 429, "MCP session capacity reached. Try again later.");
      return;
    }
    const server = createVideoVisionMcpServer();
    let createdSession: McpSession | undefined;
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: () => randomUUID(),
      enableJsonResponse: true,
      // The SDK invokes this callback as part of initialize. Persisting the
      // mapping is required so subsequent tools/list and tools/call requests
      // carrying Mcp-Session-Id reuse this exact server/transport pair.
      onsessioninitialized: (id: string) => {
        if (!createdSession) return;
        createdSession.lastUsed = Date.now();
        sessions.set(id, createdSession);
      },
    });
    createdSession = { server, transport, lastUsed: Date.now() };
    session = createdSession;
    transport.onclose = () => {
      const id = transport.sessionId;
      if (!id) return;
      const closed = sessions.get(id);
      sessions.delete(id);
      // A peer may close a session without going through closeSession().
      // Dispose the matching McpServer as well to avoid retaining handlers.
      if (closed) void closed.server.close().catch(() => undefined);
    };
    await server.connect(transport);
  }

  session.lastUsed = Date.now();
  try {
    await session.transport.handleRequest(req, res);
    // Defensive fallback for SDK versions that expose sessionId but do not
    // invoke onsessioninitialized in a custom transport lifecycle.
    const initializedSessionId = session.transport.sessionId;
    if (!sessionId && initializedSessionId) sessions.set(initializedSessionId, session);
    if (req.method === "DELETE" && sessionId) await closeSession(sessionId);
  } catch (error) {
    if (!res.headersSent) authFailure(res, 500, error instanceof Error ? error.message : String(error));
  }
}
