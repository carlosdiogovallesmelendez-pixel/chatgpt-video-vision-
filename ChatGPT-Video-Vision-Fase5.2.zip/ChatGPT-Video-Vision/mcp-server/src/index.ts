#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { registerVideoWatch } from "./tools/video-watch.js";
import { registerVideoInfo } from "./tools/video-info.js";
import { registerVideoSetup } from "./tools/video-setup.js";
import { registerVideoConfigure } from "./tools/video-configure.js";
import { registerVideoAnalyze } from "./tools/video-analyze.js";
import { registerVideoDetail } from "./tools/video-detail.js";
import { loadConfig } from "./config.js";
import { cleanExpiredSessions } from "./session/manager.js";
import { cleanExpiredDownloads } from "./utils/video-source.js";
import { getAppHome, getConfigPath, getSessionsDir } from "./utils/app-paths.js";
import { existsSync, mkdirSync } from "fs";
import { join } from "path";
import { fileURLToPath } from "url";

export function createVideoVisionMcpServer(): McpServer {
  const server = new McpServer({ name: "chatgpt-video-vision", version: "1.5.0" });
  registerVideoWatch(server);
  registerVideoInfo(server);
  registerVideoSetup(server);
  registerVideoConfigure(server);
  registerVideoAnalyze(server);
  registerVideoDetail(server);
  return server;
}

export function initializeVideoVisionStorage(): void {
  const home = getAppHome();
  mkdirSync(home, { recursive: true });
  const config = loadConfig(getConfigPath());
  if (config.enable_index) cleanExpiredSessions(getSessionsDir(), config.session_max_age_days);
  cleanExpiredDownloads(join(home, "downloads"), config.downloads_max_age_days);
}

export async function startStdioServer(): Promise<void> {
  initializeVideoVisionStorage();
  const server = createVideoVisionMcpServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  startStdioServer().catch((error) => {
    // stderr only: stdout is reserved for MCP JSON-RPC messages.
    console.error("ChatGPT Video Vision MCP server failed to start:", error);
    process.exitCode = 1;
  });
}
