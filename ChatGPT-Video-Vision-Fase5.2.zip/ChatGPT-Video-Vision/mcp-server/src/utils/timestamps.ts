import type { AudioResult, AudioTag, TranscriptionSegment } from "../types.js";

export function parseHMS(timestamp: string): number {
  const parts = timestamp.split(":").map(Number);
  if (parts.length !== 3 || parts.some((n) => Number.isNaN(n))) {
    throw new Error(`Invalid HH:MM:SS timestamp: ${timestamp}`);
  }
  const [h, m, s] = parts;
  return h * 3600 + m * 60 + s;
}

export function formatHMSPrecise(seconds: number, decimals = 3): string {
  const clamped = Math.max(0, seconds);
  const whole = Math.floor(clamped);
  const fraction = clamped - whole;
  if (fraction < 0.0005) return formatHMS(whole);
  const base = formatHMS(whole);
  const precision = Math.max(0, Math.min(3, decimals));
  if (precision === 0) return formatHMS(Math.round(clamped));
  const roundedMillis = Math.round(fraction * 1000);
  if (roundedMillis >= 1000) return formatHMS(whole + 1);
  const millis = roundedMillis.toString().padStart(3, "0").slice(0, precision);
  return `${base}.${millis.padEnd(precision, "0")}`;
}

export function formatHMS(seconds: number): string {
  const clamped = Math.max(0, seconds);
  const h = Math.floor(clamped / 3600);
  const m = Math.floor((clamped % 3600) / 60);
  const s = Math.floor(clamped % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function shiftAudioResult(
  result: AudioResult,
  offsetSeconds: number,
): AudioResult {
  if (offsetSeconds === 0) {
    return result;
  }

  const shiftSegment = <T extends TranscriptionSegment | AudioTag>(entry: T): T => ({
    ...entry,
    start: formatHMSPrecise(parseHMS(entry.start) + offsetSeconds),
    end: formatHMSPrecise(parseHMS(entry.end) + offsetSeconds),
  });

  return {
    ...result,
    transcription: result.transcription.map(shiftSegment),
    audio_tags: result.audio_tags.map(shiftSegment),
  };
}
