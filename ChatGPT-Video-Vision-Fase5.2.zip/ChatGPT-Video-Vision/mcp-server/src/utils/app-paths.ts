import { homedir } from "os";
import { join } from "path";

/** Shared storage/config root. VIDEO_VISION_HOME is set by Docker/web deployment. */
export function getAppHome(): string {
  return process.env.VIDEO_VISION_HOME || join(homedir(), ".claude-video-vision");
}

export function getConfigPath(): string {
  return join(getAppHome(), "config.json");
}

export function getSessionsDir(): string {
  return join(getAppHome(), "sessions");
}

export function getModelsDir(): string {
  return join(getAppHome(), "models");
}

export function getDownloadsDir(): string {
  return join(getAppHome(), "downloads");
}
