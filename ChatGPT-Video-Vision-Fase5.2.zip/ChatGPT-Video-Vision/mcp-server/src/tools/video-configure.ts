import { z } from "zod";
import { join } from "path";
import { getConfigPath, getSessionsDir } from "../utils/app-paths.js";
import { homedir } from "os";
import { rmSync, existsSync } from "fs";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { loadConfig, saveConfig } from "../config.js";

const CONFIG_PATH = getConfigPath();

export function registerVideoConfigure(server: McpServer): void {
  server.tool(
    "video_configure",
    "Configure video perception preferences (backend, resolution, fps, whisper model, etc.)",
    {
      backend: z.enum(["gemini-api", "local", "openai"]).optional(),
      whisper_engine: z.enum(["cpp", "python"]).optional(),
      whisper_model: z.enum(["tiny", "base", "small", "medium", "large-v3-turbo", "large-v3", "auto"]).optional(),
      whisper_at: z.boolean().optional(),
      frame_mode: z.enum(["images", "descriptions"]).optional(),
      frame_format: z.enum(["jpeg", "png", "webp"]).optional(),
      frame_resolution: z.number().min(128).max(2048).optional(),
      default_fps: z.union([z.number().positive(), z.literal("auto")]).optional(),
      max_frames: z.number().min(1).max(1000).optional(),
      frame_describer_model: z.enum(["opus", "sonnet", "haiku"]).optional(),
      enable_index: z.boolean().optional(),
      session_max_age_days: z.number().min(1).optional(),
      downloads_max_age_days: z.number().min(1).optional(),
      clear_sessions: z.boolean().optional(),
      audio_model: z.string().min(1).optional(),
      audio_max_output_tokens: z.number().min(1024).max(200000).optional(),
      audio_chunk_trigger_seconds: z.number().min(60).optional(),
      audio_chunk_size_seconds: z.number().min(60).optional(),
      audio_chunk_overlap_seconds: z.number().min(0).max(60).optional(),
      vision_model: z.string().min(1).optional(),
      vision_max_frames: z.number().min(1).max(48).optional(),
      vision_detail: z.enum(["low", "high", "auto"]).optional(),
      openai_audio_events_enabled: z.boolean().optional(),
    },
    async (params) => {
      if (params.clear_sessions) {
        const sessionsDir = getSessionsDir();
        if (existsSync(sessionsDir)) {
          rmSync(sessionsDir, { recursive: true, force: true });
        }
      }

      const current = loadConfig(CONFIG_PATH);
      const updated = { ...current };

      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && key !== "clear_sessions") {
          (updated as any)[key] = value;
        }
      }

      saveConfig(CONFIG_PATH, updated);

      let responseText = `Configuration saved to ${CONFIG_PATH}:\n${JSON.stringify(updated, null, 2)}`;
      if (params.clear_sessions) {
        responseText += "\n\nAll sessions have been cleared.";
      }
      return { content: [{ type: "text", text: responseText }] };
    },
  );
}
