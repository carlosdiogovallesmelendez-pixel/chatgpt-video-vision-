import { z } from "zod";
import { join } from "path";
import { getConfigPath, getSessionsDir, getModelsDir } from "../utils/app-paths.js";
import { homedir } from "os";
import { copyFileSync, mkdirSync, rmSync } from "fs";
import { tmpdir } from "os";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { loadConfig } from "../config.js";
import {
  getVideoMetadata,
  extractFrames,
  calculateAutoFps,
  extractFramesBySegments,
  frameFormatExtension,
  frameFormatMimeType,
} from "../extractors/frames.js";
import { extractAudio } from "../extractors/audio.js";
import { analyzeWithGeminiApi } from "../backends/gemini-api.js";
import { transcribeWithWhisper } from "../backends/local.js";
import { transcribeWithOpenAI } from "../backends/openai.js";
import { analyzeAudioEventsWithOpenAI } from "../backends/openai-audio-events.js";
import { analyzeFramesWithOpenAI } from "../backends/openai-vision.js";
import { parseHMS, shiftAudioResult } from "../utils/timestamps.js";
import {
  buildCaptionAudioResult,
  getCaptionFallbackReason,
  resolveVideoInputDetailed,
} from "../utils/video-source.js";
import { getSessionDir, loadManifest, saveManifest, computeVideoHash } from "../session/manager.js";
import { createManifest, frameCacheKey, mergeFrames, sampleFrameIndices } from "../session/manifest.js";
import type { AudioResult, VideoWatchResult, Frame, FrameFormat, Segment, SessionManifest } from "../types.js";

const CONFIG_PATH = getConfigPath();

const HMS_REGEX = /^\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?$/;

const SESSIONS_DIR = getSessionsDir();

const UNCONFIGURED_MESSAGE = `## ChatGPT Video Vision ainda não está configurado!

Configure um backend de áudio no servidor com a ferramenta video_configure e defina as variáveis de ambiente correspondentes antes de solicitar transcrição.

Backends disponíveis:
- **Gemini API** — transcrição e identificação de eventos sonoros; requer GEMINI_API_KEY.
- **OpenAI API** — transcrição; requer OPENAI_API_KEY. Os timestamps detalhados dependem do modelo selecionado.
- **Whisper local** — processamento local; requer os binários/modelos correspondentes no servidor.`;

function timestampToFormattedFilename(timestamp: string, extension: string): string {
  return `${timestamp.replace(/:/g, "-")}.${extension}`;
}

/**
 * Copies extracted frames into the session cache under stable,
 * timestamp-keyed filenames and indexes those copies in the manifest.
 * ffmpeg's frame_XXXX names restart on every run, so they must never be
 * referenced from the manifest directly.
 */
export function persistFramesToSession(
  manifest: SessionManifest,
  sessionDir: string,
  frameFormat: FrameFormat,
  frames: { timestamp: string; resolution: number | string; sourcePath?: string }[],
): SessionManifest {
  const extension = frameFormatExtension(frameFormat);
  const entriesByCacheKey = new Map<string, { timestamp: string; file: string }[]>();

  for (const frame of frames) {
    if (!frame.sourcePath) continue;

    const resDir = join(sessionDir, "frames", frameFormat, String(frame.resolution));
    mkdirSync(resDir, { recursive: true });
    const filePath = join(resDir, timestampToFormattedFilename(frame.timestamp, extension));
    copyFileSync(frame.sourcePath, filePath);

    const cacheKey = frameCacheKey(frame.resolution, frameFormat);
    const entries = entriesByCacheKey.get(cacheKey) ?? [];
    entries.push({ timestamp: frame.timestamp, file: filePath });
    entriesByCacheKey.set(cacheKey, entries);
  }

  for (const [cacheKey, entries] of entriesByCacheKey) {
    manifest = mergeFrames(manifest, cacheKey, entries);
  }
  return manifest;
}

export interface DeriveFpsParams {
  fps: number | "auto";
  view_sample?: number;
  start_time?: string;
  end_time?: string;
  segments?: { start: string; end: string }[];
  duration_seconds: number;
}

export function deriveFps(params: DeriveFpsParams): number {
  const usingSegments = params.segments && params.segments.length > 0;
  if (params.fps === "auto") {
    if (params.view_sample && !usingSegments) {
      const startSec = params.start_time ? parseHMS(params.start_time) : 0;
      const endSec = params.end_time ? parseHMS(params.end_time) : params.duration_seconds;
      const activeDuration = Math.max(1, endSec - startSec);
      return params.view_sample / activeDuration;
    }
    return calculateAutoFps(params.duration_seconds);
  }
  return params.fps;
}

export function registerVideoWatch(server: McpServer): void {
  server.tool(
    "video_watch",
    "Extract frames and process audio from a local video file or YouTube URL. Returns frames (as base64 images or text descriptions) + transcription + audio analysis for multimodal interpretation by a compatible client or the optional OpenAI vision adapter. IMPORTANT: For videos longer than 30 seconds, call video_analyze FIRST to get structural data (scene changes, silence, transcription) before calling this tool — use that data to set smart segments with variable FPS. When the video is long enough to trigger audio chunking, the result's `audio.warnings` array (if present) reports chunk-boundary decisions and any per-chunk retries or failures — surface these to the user.",
    {
      path: z.string().describe("Absolute/relative path to the video file, or a YouTube URL"),
      fps: z.union([z.coerce.number().positive(), z.literal("auto")]).default("auto").describe("Frames per second to extract"),
      resolution: z.coerce.number().min(128).max(2048).optional().describe("Frame width in px (maintains aspect ratio)"),
      frame_mode: z.enum(["images", "descriptions"]).optional().describe("Return frames as base64 images or text descriptions"),
      frame_format: z.enum(["jpeg", "png", "webp"]).optional().describe("Frame image format for extraction"),
      describer_model: z.enum(["opus", "sonnet", "haiku"]).optional().describe("Legacy compatibility field; not used by the OpenAI vision adapter"),
      start_time: z.string().regex(HMS_REGEX, "Must be HH:MM:SS or HH:MM:SS.mmm format").optional().describe("Absolute timestamp where extraction starts (measured from the video's 00:00:00). Format: 'HH:MM:SS'."),
      end_time: z.string().regex(HMS_REGEX, "Must be HH:MM:SS or HH:MM:SS.mmm format").optional().describe(
        "Absolute timestamp where extraction ends (NOT a duration). " +
        "Format: 'HH:MM:SS'. " +
        "Example: to extract from 1:00 to 1:10, use start_time='00:01:00' end_time='00:01:10'."
      ),
      skip_audio: z.boolean().default(false).describe("Skip audio extraction and transcription — frames only"),
      segments: z.array(z.object({
        start: z.string().regex(HMS_REGEX, "Must be HH:MM:SS or HH:MM:SS.mmm format").describe("Absolute timestamp where this segment starts (measured from the video's 00:00:00)."),
        end: z.string().regex(HMS_REGEX, "Must be HH:MM:SS or HH:MM:SS.mmm format").describe("Absolute timestamp where this segment ends (NOT a duration relative to `start`)."),
        fps: z.number().positive(),
        resolution: z.number().min(128).max(2048).optional(),
      })).optional().describe("Variable FPS/resolution segments — overrides global fps/start_time/end_time"),
      view_sample: z.number().min(1).optional().describe("Return only N evenly spaced frames"),
      visual_analysis: z.boolean().default(false).describe("Analyze extracted frames using the configured OpenAI vision model. Requires OPENAI_API_KEY on the server."),
    },
    async (params) => {
      const config = loadConfig(CONFIG_PATH);

      const resolution = params.resolution || config.frame_resolution;
      const frameMode = params.frame_mode || config.frame_mode;
      const resolved = await resolveVideoInputDetailed(params.path);
      const safePath = resolved.path;
      const frameFormat = params.frame_format || config.frame_format;
      const frameMimeType = frameFormatMimeType(frameFormat);

      // Session support
      const useSession = config.enable_index;
      let sessionDir: string | null = null;
      let manifest: SessionManifest | null = null;

      if (useSession) {
        sessionDir = getSessionDir(SESSIONS_DIR, safePath);
        manifest = loadManifest(sessionDir) ?? createManifest(computeVideoHash(safePath), safePath);
      }

      // 1. Get metadata
      const metadata = await getVideoMetadata(safePath);
      const captionFallbackReason = resolved.source?.type === "youtube"
        ? getCaptionFallbackReason(resolved.captions, metadata.duration_seconds)
        : null;

      if (config.backend === "unconfigured" && !params.skip_audio && captionFallbackReason !== null) {
        return { content: [{ type: "text", text: UNCONFIGURED_MESSAGE }] };
      }

      // 2. Calculate fps
      const fps = deriveFps({
        fps: params.fps,
        view_sample: params.view_sample,
        start_time: params.start_time,
        end_time: params.end_time,
        segments: params.segments,
        duration_seconds: metadata.duration_seconds,
      });

      // 3. Prepare work dir
      const workDir = join(tmpdir(), `cvv-${Date.now()}`);
      mkdirSync(workDir, { recursive: true });

      try {
        const framesDir = join(workDir, "frames");

        // 4. Run frame extraction and audio processing
        //    When segments are provided, frame extraction is sequential (per segment);
        //    audio can still run in parallel with the entire segment batch.

        let framesPromise: Promise<Frame[]>;

        if (params.segments && params.segments.length > 0) {
          framesPromise = extractFramesBySegments(safePath, params.segments as Segment[], framesDir, frameFormat).then((segmentFrames) => {
            if (useSession && manifest && sessionDir) {
              manifest = persistFramesToSession(manifest, sessionDir, frameFormat, segmentFrames);
            }
            return segmentFrames;
          });
        } else {
          framesPromise = extractFrames(safePath, {
            fps,
            resolution,
            outputDir: framesDir,
            format: frameFormat,
            startTime: params.start_time,
            endTime: params.end_time,
            maxFrames: config.max_frames,
          }).then((extractedFrames) => {
            if (useSession && manifest && sessionDir) {
              manifest = persistFramesToSession(
                manifest,
                sessionDir,
                frameFormat,
                extractedFrames.map((frame) => ({ ...frame, resolution })),
              );
            }

            return extractedFrames;
          });
        }

        let audioPromise: Promise<AudioResult>;

        if (params.skip_audio || !metadata.has_audio) {
          audioPromise = Promise.resolve({ backend: "none" as const, transcription: [], audio_tags: [], full_analysis: null });
        } else if (captionFallbackReason === null && resolved.captions) {
          audioPromise = Promise.resolve(
            buildCaptionAudioResult(resolved.captions, {
              startTime: params.start_time,
              endTime: params.end_time,
            }),
          );
        } else if (config.backend === "gemini-api") {
          audioPromise = analyzeWithGeminiApi(safePath, config, {
            startTime: params.start_time,
            endTime: params.end_time,
          });
        } else if (config.backend === "openai") {
          const audioDir = join(workDir, "audio");
          audioPromise = extractAudio(safePath, audioDir, {
            startTime: params.start_time,
            endTime: params.end_time,
          }).then(async (wavPath) => {
            const result = await transcribeWithOpenAI(wavPath);
            if (config.openai_audio_events_enabled) {
              try {
                result.audio_tags = await analyzeAudioEventsWithOpenAI(wavPath);
              } catch (error) {
                result.warnings = [...(result.warnings ?? []), {
                  chunk_index: 0, chunk_total: 1, time_range: "full audio", event: "failed",
                  detail: `Optional OpenAI sound-event analysis failed: ${error instanceof Error ? error.message : String(error)}`,
                }];
              }
            }
            return result;
          });
        } else {
          // local
          const audioDir = join(workDir, "audio");
          const modelDir = getModelsDir();
          audioPromise = extractAudio(safePath, audioDir, {
            startTime: params.start_time,
            endTime: params.end_time,
          }).then((wavPath) =>
            transcribeWithWhisper(wavPath, {
              engine: config.whisper_engine,
              model: config.whisper_model,
              whisperAt: config.whisper_at,
              modelDir,
            }),
          );
        }

        let [frames, rawAudio] = await Promise.all([framesPromise, audioPromise]);

        if (captionFallbackReason !== null && rawAudio.backend !== "youtube-captions" && rawAudio.backend !== "none") {
          rawAudio = { ...rawAudio, transcription_fallback_reason: captionFallbackReason };
        }

        // 5. Align audio timestamps with the original video timeline.
        //    Backends return timestamps relative to the cropped audio, but frames
        //    already carry original-video timestamps via extractFrames. Shift the
        //    audio result so both timelines match.
        const offsetSeconds = params.start_time ? parseHMS(params.start_time) : 0;
        const audio = shiftAudioResult(rawAudio, offsetSeconds);

        // 6. Apply view_sample filtering — return only N evenly spaced frames
        if (params.view_sample && frames.length > params.view_sample) {
          const indices = sampleFrameIndices(frames.length, params.view_sample);
          frames = indices.map((i) => frames[i]);
        }

        // 7. Persist session manifest
        if (useSession && manifest && sessionDir) {
          saveManifest(sessionDir, manifest);
        }

        // 8. Optional visual analysis. This is explicitly opt-in to avoid unexpected API charges.
        let visualAnalysis: Awaited<ReturnType<typeof analyzeFramesWithOpenAI>> | null = null;
        if (params.visual_analysis) {
          const visionFrames = frames.filter((frame) => Boolean(frame.image)).slice(0, config.vision_max_frames);
          visualAnalysis = await analyzeFramesWithOpenAI(visionFrames, {
            model: config.vision_model,
            detail: config.vision_detail,
            maxFrames: config.vision_max_frames,
          });
        }

        // 9. Build result (preserves original metadata, frames and audio contract).
        const result: VideoWatchResult = { metadata, frames, audio };

        // 10. Return as MCP content
        const content: Array<{ type: "text"; text: string } | { type: "image"; data: string; mimeType: string }> = [];

        if (resolved.source) {
          content.push({ type: "text", text: `## Source\n${JSON.stringify(resolved.source, null, 2)}` });
        }

        // Manifest summary (only when session is active)
        if (manifest) {
          const manifestSummary = {
            video_hash: manifest.video_hash,
            resolutions: Object.fromEntries(
              Object.entries(manifest.resolutions).map(([res, data]) => [
                res, { frame_count: data.frames.length, timestamps: data.frames.map((f) => f.timestamp) },
              ]),
            ),
          };
          content.push({ type: "text", text: `## Session Manifest\n${JSON.stringify(manifestSummary, null, 2)}` });
        }

        // Metadata + audio as text
        content.push({
          type: "text",
          text: `## Video Metadata\n${JSON.stringify(metadata, null, 2)}\n\n## Audio Analysis\n${JSON.stringify(audio, null, 2)}`,
        });

        if (visualAnalysis) {
          content.push({ type: "text", text: `## OpenAI Visual Analysis\n${JSON.stringify(visualAnalysis, null, 2)}` });
        }

        // Frames
        if (frameMode === "images") {
          for (const frame of frames) {
            content.push({
              type: "text",
              text: `### Frame at ${frame.timestamp}`,
            });
            if (frame.image) {
              content.push({
                type: "image",
                data: frame.image,
                mimeType: frameMimeType,
              });
            }
          }
        } else {
          // descriptions mode — keep images in the MCP response for clients that perform their own interpretation
          content.push({
            type: "text",
            text: `## Frames (${frames.length} extracted at ${fps} fps)\nFrame mode is "descriptions" — frames are returned for multimodal interpretation by the client or the optional OpenAI visual analysis.\n\n${frames.map((f) => `- ${f.timestamp}`).join("\n")}`,
          });
          // Still include images so the agent can describe them
          for (const frame of frames) {
            if (frame.image) {
              content.push({
                type: "image",
                data: frame.image,
                mimeType: frameMimeType,
              });
            }
          }
        }

        return { content: content as any };
      } finally {
        rmSync(workDir, { recursive: true, force: true });
      }
    },
  );
}
