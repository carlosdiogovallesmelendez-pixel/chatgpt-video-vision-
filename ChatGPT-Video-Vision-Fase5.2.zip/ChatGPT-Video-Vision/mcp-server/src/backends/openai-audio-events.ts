import { execFile } from "child_process";
import { mkdtempSync, readFileSync, rmSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { promisify } from "util";
import type { AudioTag } from "../types.js";
import { formatHMSPrecise, parseHMS } from "../utils/timestamps.js";

const execFileAsync = promisify(execFile);

export function parseAudioEventsResponse(raw: string): AudioTag[] {
  const cleaned = raw.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  let parsed: any;
  try { parsed = JSON.parse(cleaned); }
  catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start < 0 || end <= start) throw new Error("Audio model returned invalid JSON.");
    parsed = JSON.parse(cleaned.slice(start, end + 1));
  }
  if (!Array.isArray(parsed.audio_tags)) throw new Error("Audio model response is missing audio_tags.");
  return parsed.audio_tags.map((tag: any) => {
    if (typeof tag?.start !== "string" || typeof tag?.end !== "string" || typeof tag?.tag !== "string") {
      throw new Error("Audio event has an invalid schema.");
    }
    const start = parseHMS(tag.start);
    const end = parseHMS(tag.end);
    if (end < start) throw new Error("Audio event end precedes its start.");
    return { start: formatHMSPrecise(start), end: formatHMSPrecise(end), tag: tag.tag.slice(0, 100).toLowerCase() };
  });
}

async function getDuration(path: string): Promise<number> {
  const { stdout } = await execFileAsync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", path]);
  const value = Number(stdout.trim());
  if (!Number.isFinite(value) || value <= 0) throw new Error("Could not determine extracted audio duration.");
  return value;
}

async function classifyChunk(wavPath: string): Promise<AudioTag[]> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is required for OpenAI sound-event analysis.");
  const buffer = readFileSync(wavPath);
  if (buffer.length > 18 * 1024 * 1024) throw new Error("Audio chunk exceeds the 18 MB request safety limit.");
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_AUDIO_EVENTS_MODEL || "gpt-audio-1.5",
      modalities: ["text"],
      messages: [{
        role: "user",
        content: [
          { type: "text", text: "Identify non-speech sounds only (music, ambient sounds, mechanical sounds, impacts, animals, weather). Return JSON only: {audio_tags:[{start:'HH:MM:SS',end:'HH:MM:SS',tag:'short lowercase label'}]}. Timestamps are relative to this audio clip. Do not transcribe speech. Return an empty array if no identifiable non-speech event exists. Do not guess." },
          { type: "input_audio", input_audio: { data: buffer.toString("base64"), format: "wav" } },
        ],
      }],
    }),
    signal: AbortSignal.timeout(180_000),
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(`OpenAI audio-event API returned HTTP ${response.status}: ${raw.slice(0, 1000)}`);
  const payload = JSON.parse(raw) as any;
  const content = payload?.choices?.[0]?.message?.content;
  const text = typeof content === "string" ? content : Array.isArray(content) ? content.map((p: any) => p.text || "").join("\n") : "";
  if (!text) throw new Error("OpenAI audio-event API returned no text payload.");
  return parseAudioEventsResponse(text);
}

/** Analyze a WAV in 2-minute clips to keep audio requests bounded. */
export async function analyzeAudioEventsWithOpenAI(wavPath: string): Promise<AudioTag[]> {
  const work = mkdtempSync(join(tmpdir(), "cvv-openai-audio-events-"));
  try {
    const duration = await getDuration(wavPath);
    const chunkSeconds = 120;
    const tags: AudioTag[] = [];
    for (let start = 0, index = 0; start < duration; start += chunkSeconds, index++) {
      const end = Math.min(duration, start + chunkSeconds);
      const chunkPath = join(work, `chunk-${index}.wav`);
      await execFileAsync("ffmpeg", ["-hide_banner", "-loglevel", "error", "-ss", String(start), "-i", wavPath, "-t", String(end - start), "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1", "-y", chunkPath], { timeout: 120_000 });
      const localTags = await classifyChunk(chunkPath);
      for (const tag of localTags) {
        const offset = (value: string) => formatHMSPrecise(parseHMS(value) + start);
        tags.push({ start: offset(tag.start), end: offset(tag.end), tag: tag.tag });
      }
    }
    return tags;
  } finally {
    rmSync(work, { recursive: true, force: true });
  }
}
