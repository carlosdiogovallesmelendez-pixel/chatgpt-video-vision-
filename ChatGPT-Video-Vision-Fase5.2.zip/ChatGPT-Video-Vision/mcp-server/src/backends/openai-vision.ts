import type { Frame } from "../types.js";

export interface VisionFrameDescription {
  timestamp: string;
  description: string;
  observed_changes: string[];
  confidence_notes: string[];
}

export interface VisionAnalysisResult {
  model: string;
  frames: VisionFrameDescription[];
  summary: string;
  limitations: string[];
}

function getOutputText(payload: any): string {
  if (typeof payload?.output_text === "string") return payload.output_text;
  const parts: string[] = [];
  for (const item of payload?.output ?? []) {
    for (const content of item?.content ?? []) {
      if (content?.type === "output_text" && typeof content.text === "string") parts.push(content.text);
    }
  }
  return parts.join("\n").trim();
}

function parseJsonText(value: string): any {
  const cleaned = value.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  try { return JSON.parse(cleaned); } catch { /* try the first JSON object */ }
  const first = cleaned.indexOf("{");
  const last = cleaned.lastIndexOf("}");
  if (first >= 0 && last > first) return JSON.parse(cleaned.slice(first, last + 1));
  throw new Error("The vision model did not return a valid JSON object.");
}

/** Analyze sampled video frames with the OpenAI Responses API. Frames remain timestamped. */
export async function analyzeFramesWithOpenAI(
  frames: Frame[],
  options: { model?: string; detail?: "low" | "high" | "auto"; maxFrames?: number } = {},
): Promise<VisionAnalysisResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is required for visual analysis. Configure it on the server; never put it in the browser.");

  const usable = frames.filter((frame) => typeof frame.image === "string" && frame.image.length > 0);
  if (usable.length === 0) throw new Error("No extracted frame images were available for visual analysis.");
  const limit = Math.max(1, Math.min(options.maxFrames ?? 24, 48));
  const selected = usable.slice(0, limit);
  const content: Array<Record<string, unknown>> = [{
    type: "input_text",
    text: [
      "Analyze this timestamped sequence of still frames extracted from one video.",
      "Describe only what is visible. Compare frames to identify observable changes and actions.",
      "Do not infer audio, identity, intent, or events that are not supported by the images.",
      "Use the supplied timestamps exactly. The sampling may miss motion between frames.",
      "Return JSON with this shape: {summary:string, frames:[{timestamp:string,description:string,observed_changes:string[],confidence_notes:string[]}],limitations:string[]}.",
      "Include one frame entry for every supplied image in the same order.",
    ].join(" "),
  }];

  for (const frame of selected) {
    const mime = frame.format === "png" ? "image/png" : frame.format === "webp" ? "image/webp" : "image/jpeg";
    content.push({ type: "input_text", text: `Timestamp: ${frame.timestamp}` });
    content.push({
      type: "input_image",
      image_url: `data:${mime};base64,${frame.image}`,
      detail: options.detail ?? "low",
    });
  }

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: options.model || "gpt-6.1-terra",
      input: [{ role: "user", content }],
    }),
    signal: AbortSignal.timeout(180_000),
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(`OpenAI vision API returned HTTP ${response.status}: ${raw.slice(0, 1200)}`);

  let payload: any;
  try { payload = JSON.parse(raw); } catch { throw new Error("OpenAI vision API returned invalid JSON transport data."); }
  const text = getOutputText(payload);
  const parsed = parseJsonText(text);
  if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.frames)) {
    throw new Error("OpenAI vision response did not contain the expected frames array.");
  }

  const descriptions: VisionFrameDescription[] = parsed.frames.map((item: any, index: number) => ({
    timestamp: typeof item?.timestamp === "string" ? item.timestamp : selected[index]?.timestamp ?? "00:00:00",
    description: typeof item?.description === "string" ? item.description : "Description unavailable.",
    observed_changes: Array.isArray(item?.observed_changes) ? item.observed_changes.filter((v: unknown) => typeof v === "string") : [],
    confidence_notes: Array.isArray(item?.confidence_notes) ? item.confidence_notes.filter((v: unknown) => typeof v === "string") : [],
  }));

  return {
    model: typeof payload.model === "string" ? payload.model : options.model || "gpt-6.1-terra",
    frames: descriptions,
    summary: typeof parsed.summary === "string" ? parsed.summary : "Visual analysis completed.",
    limitations: Array.isArray(parsed.limitations) ? parsed.limitations.filter((v: unknown) => typeof v === "string") : ["Analysis is based on sampled still frames, not continuous video."],
  };
}
