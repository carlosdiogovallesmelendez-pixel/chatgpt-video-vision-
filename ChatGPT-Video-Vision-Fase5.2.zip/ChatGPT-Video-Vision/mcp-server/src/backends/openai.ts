import { execFile } from "child_process";
import { mkdtempSync, readFileSync, rmSync, statSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import { promisify } from "util";
import type { AudioResult, TranscriptionSegment } from "../types.js";
import { formatHMS, formatHMSPrecise } from "../utils/timestamps.js";

const execFileAsync = promisify(execFile);
const MAX_REQUEST_BYTES = 20 * 1024 * 1024; // Stay below the documented 25 MB upload limit.
const CHUNK_SECONDS = 8 * 60; // 16 kHz mono PCM WAV is ~1.92 MB/minute.

function asText(payload: any): string {
  if (typeof payload?.text === "string") return payload.text;
  if (typeof payload?.transcript === "string") return payload.transcript;
  return "";
}

export function mapTranscriptionResponse(
  payload: any,
  model: string,
  offsetSeconds = 0,
): Pick<AudioResult, "transcription" | "transcription_timing"> {
  if (model === "whisper-1" && Array.isArray(payload?.segments)) {
    const transcription = payload.segments.map((seg: any) => {
      const start = Math.max(0, Number(seg.start) || 0) + offsetSeconds;
      const end = Math.max(Number(seg.start) || 0, Number(seg.end) || Number(seg.start) || 0) + offsetSeconds;
      return {
        start: formatHMSPrecise(start),
        end: formatHMSPrecise(end),
        text: String(seg.text ?? "").trim(),
      };
    }).filter((segment: TranscriptionSegment) => segment.text.length > 0);
    return { transcription, transcription_timing: "measured" };
  }

  const text = asText(payload).trim();
  return {
    // gpt-transcribe does not currently provide segment timestamps. Never invent them.
    transcription: text ? [{ start: "00:00:00", end: "00:00:00", text }] : [],
    transcription_timing: "unavailable",
  };
}

async function getDurationSeconds(wavPath: string): Promise<number> {
  const { stdout } = await execFileAsync("ffprobe", [
    "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", wavPath,
  ]);
  const duration = Number(stdout.trim());
  if (!Number.isFinite(duration) || duration <= 0) throw new Error("Could not determine the audio duration for transcription chunking.");
  return duration;
}

async function transcribeSingle(wavPath: string, model: string, offsetSeconds: number): Promise<ReturnType<typeof mapTranscriptionResponse>> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY environment variable is not set. Set it on the server environment; do not expose it to the browser.");

  const form = new FormData();
  const bytes = new Uint8Array(readFileSync(wavPath));
  form.append("file", new Blob([bytes], { type: "audio/wav" }), "audio.wav");
  form.append("model", model);
  form.append("response_format", model === "whisper-1" ? "verbose_json" : "json");
  if (model === "whisper-1") form.append("timestamp_granularities[]", "segment");

  const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
    signal: AbortSignal.timeout(180_000),
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(`OpenAI transcription API returned HTTP ${response.status}: ${raw.slice(0, 1200)}`);

  let payload: any;
  try { payload = JSON.parse(raw); }
  catch { payload = { text: raw }; }
  return mapTranscriptionResponse(payload, model, offsetSeconds);
}

/**
 * Transcribe audio through OpenAI. Large 16 kHz mono WAV files are split into
 * bounded chunks before upload, keeping every request below 20 MB. Exact
 * timestamps are returned only when the selected backend/model measured them.
 */
export async function transcribeWithOpenAI(wavPath: string): Promise<AudioResult> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY environment variable is not set. Set it on the server environment; do not expose it to the browser.");
  }

  const model = process.env.OPENAI_TRANSCRIPTION_MODEL || "gpt-transcribe";
  const fileSize = statSync(wavPath).size;
  const workDir = mkdtempSync(join(tmpdir(), "cvv-openai-transcription-"));
  try {
    const chunks: Array<{ path: string; offset: number }> = [];
    if (fileSize <= MAX_REQUEST_BYTES) {
      chunks.push({ path: wavPath, offset: 0 });
    } else {
      const duration = await getDurationSeconds(wavPath);
      for (let offset = 0, index = 0; offset < duration; offset += CHUNK_SECONDS, index++) {
        const chunkPath = join(workDir, `audio-${index}.wav`);
        await execFileAsync("ffmpeg", [
          "-hide_banner", "-loglevel", "error", "-ss", String(offset), "-i", wavPath,
          "-t", String(Math.min(CHUNK_SECONDS, duration - offset)), "-vn", "-acodec", "pcm_s16le",
          "-ar", "16000", "-ac", "1", "-y", chunkPath,
        ], { timeout: 120_000 });
        if (statSync(chunkPath).size > MAX_REQUEST_BYTES) {
          throw new Error("A split transcription chunk still exceeds the safe 20 MB request limit.");
        }
        chunks.push({ path: chunkPath, offset });
      }
    }

    const allSegments: TranscriptionSegment[] = [];
    const warnings: AudioResult["warnings"] = [];
    let timing: "measured" | "unavailable" = "measured";
    for (let index = 0; index < chunks.length; index++) {
      const chunk = chunks[index];
      const mapped = await transcribeSingle(chunk.path, model, chunk.offset);
      allSegments.push(...mapped.transcription);
      if (mapped.transcription_timing !== "measured") timing = "unavailable";
      if (chunks.length > 1 && model !== "whisper-1") {
        warnings?.push({
          chunk_index: index,
          chunk_total: chunks.length,
          time_range: `${formatHMS(chunk.offset)}-${formatHMS(chunk.offset + CHUNK_SECONDS)}`,
          event: "hard_cut",
          detail: "Chunked transcription has no measured segment timestamps for this model; chunk boundaries are not speech timestamps.",
        });
      }
    }

    let transcription = allSegments;
    if (timing === "unavailable") {
      const combinedText = allSegments.map((segment) => segment.text).filter(Boolean).join(" ").trim();
      transcription = combinedText ? [{ start: "00:00:00", end: "00:00:00", text: combinedText }] : [];
    }

    return {
      backend: "openai",
      transcription,
      audio_tags: [],
      full_analysis: null,
      transcription_source: "openai",
      transcription_source_detail: model,
      transcription_timing: timing,
      ...(timing === "unavailable" ? {
        warnings: [...(warnings ?? []), {
          chunk_index: 0, chunk_total: chunks.length, time_range: "unknown", event: "loose_threshold" as const,
          detail: "The selected OpenAI transcription model returned text without measured segment timestamps. Timestamps were not fabricated.",
        }],
      } : warnings?.length ? { warnings } : {}),
    };
  } finally {
    rmSync(workDir, { recursive: true, force: true });
  }
}
