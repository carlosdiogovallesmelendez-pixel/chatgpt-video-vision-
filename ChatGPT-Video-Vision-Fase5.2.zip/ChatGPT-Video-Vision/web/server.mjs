import http from 'node:http';
import { spawn, execFile } from 'node:child_process';
import { createReadStream, createWriteStream } from 'node:fs';
import { mkdir, readFile, writeFile, readdir, stat, unlink, chmod } from 'node:fs/promises';
import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { once } from 'node:events';
import { promisify } from 'node:util';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const execFileAsync = promisify(execFile);
const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const PUBLIC_DIR = path.join(HERE, 'public');
const STORAGE = path.resolve(process.env.VIDEO_VISION_HOME || path.join(ROOT, 'storage'));
const UPLOADS = path.join(STORAGE, 'uploads');
const JOBS = path.join(STORAGE, 'jobs');
const RESULTS = path.join(STORAGE, 'results');
const UPLOADS_META = path.join(STORAGE, 'upload-meta');
const MCP_ENTRY = path.join(ROOT, 'mcp-server', 'dist', 'index.js');
const PORT = Number(process.env.PORT || 8080);
const MAX_UPLOAD_MB = Math.max(1, Math.min(2048, Number(process.env.MAX_UPLOAD_MB || 512)));
const MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024;
const RETENTION_HOURS = Math.max(1, Number(process.env.RETENTION_HOURS || 24));
const MAX_STORAGE_MB = Math.max(MAX_UPLOAD_MB, Number(process.env.MAX_STORAGE_MB || 4096));
const MAX_PENDING_JOBS = Math.max(1, Math.min(50, Number(process.env.MAX_PENDING_JOBS || 10)));
const SESSION_TTL_SECONDS = 12 * 60 * 60;
const ALLOWED_EXTENSIONS = new Set(['.mp4', '.mov', '.m4v', '.mkv', '.webm', '.avi', '.mpeg', '.mpg', '.wmv', '.flv', '.3gp']);
const SAFE_TOOL_NAMES = new Set(['video_watch', 'video_analyze', 'video_detail', 'video_info', 'video_configure', 'video_setup']);
const jobs = new Map();
const queue = [];
let workerRunning = false;
let mcpClient = null;

function envRequired(name, minLength = 1) {
  const value = process.env[name];
  if (!value || value.length < minLength) throw new Error(`${name} must be configured (minimum ${minLength} characters).`);
  return value;
}

function safeError(value) {
  return String(value instanceof Error ? value.message : value)
    .replace(/sk-[A-Za-z0-9_-]{12,}/g, '[REDACTED_API_KEY]')
    .replace(/AIza[0-9A-Za-z_-]{20,}/g, '[REDACTED_API_KEY]')
    .slice(0, 1800);
}

function json(res, status, body, extraHeaders = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Cross-Origin-Resource-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Referrer-Policy': 'no-referrer',
    ...extraHeaders,
  });
  res.end(payload);
}

function constantTimeStringEqual(left, right) {
  const a = createHash('sha256').update(String(left)).digest();
  const b = createHash('sha256').update(String(right)).digest();
  return timingSafeEqual(a, b);
}

function signSession(payload) {
  return createHmac('sha256', envRequired('SESSION_SECRET', 32)).update(payload).digest('base64url');
}

function issueSession(username) {
  const payload = Buffer.from(JSON.stringify({ sub: username, exp: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS, nonce: randomBytes(12).toString('hex') })).toString('base64url');
  const token = `${payload}.${signSession(payload)}`;
  const nonce = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')).nonce;
  activeSessions.set(nonce, Date.now() + SESSION_TTL_SECONDS * 1000);
  if (activeSessions.size > 500) {
    const now = Date.now();
    for (const [key, expires] of activeSessions) if (expires <= now) activeSessions.delete(key);
  }
  return token;
}

function validSession(req) {
  try {
    const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map((part) => {
      const index = part.indexOf('=');
      return index > 0 ? [part.slice(0, index).trim(), part.slice(index + 1).trim()] : ['', ''];
    }).filter(([key]) => key));
    const token = cookies.cvv_session || '';
    const [payload, signature] = token.split('.');
    if (!payload || !signature || !constantTimeStringEqual(signSession(payload), signature)) return false;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return typeof data.sub === 'string' && data.exp > Math.floor(Date.now() / 1000) && activeSessions.has(data.nonce);
  } catch { return false; }
}

const loginAttempts = new Map();
const activeSessions = new Map();
function loginRateAllowed(req) {
  const key = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const entry = loginAttempts.get(key) || { count: 0, start: now };
  if (now - entry.start > 15 * 60_000) { entry.count = 0; entry.start = now; }
  entry.count += 1;
  loginAttempts.set(key, entry);
  return entry.count <= 8;
}

function assertSameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}

async function readJson(req, limit = 1024 * 1024) {
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > limit) throw Object.assign(new Error('Request body is too large.'), { statusCode: 413 });
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw Object.assign(new Error('Request body is too large.'), { statusCode: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON request body.'), { statusCode: 400 }); }
}

async function directoryBytes(directory) {
  let total = 0;
  for (const entry of await readdir(directory, { withFileTypes: true }).catch(() => [])) {
    const target = path.join(directory, entry.name);
    if (entry.isSymbolicLink()) continue;
    if (entry.isDirectory()) total += await directoryBytes(target);
    else if (entry.isFile()) total += (await stat(target).catch(() => null))?.size || 0;
  }
  return total;
}

async function storeUpload(req) {
  const usedBytes = await directoryBytes(STORAGE);
  if (usedBytes >= MAX_STORAGE_MB * 1024 * 1024) throw Object.assign(new Error('Server storage quota is full. Remove old videos/results or increase MAX_STORAGE_MB.'), { statusCode: 507 });
  const extension = path.extname(decodeURIComponent(String(req.headers['x-file-name'] || 'video.mp4').replace(/[\\/]/g, '_'))).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(extension)) throw Object.assign(new Error('Unsupported video file extension.'), { statusCode: 415 });
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > MAX_UPLOAD_BYTES) throw Object.assign(new Error(`Upload exceeds the ${MAX_UPLOAD_MB} MB limit.`), { statusCode: 413 });

  const id = randomUUID();
  const target = path.join(UPLOADS, `${id}${extension}`);
  const writer = createWriteStream(target, { flags: 'wx', mode: 0o600 });
  let size = 0;
  try {
    for await (const chunk of req) {
      size += chunk.length;
      if (size > MAX_UPLOAD_BYTES) throw Object.assign(new Error(`Upload exceeds the ${MAX_UPLOAD_MB} MB limit.`), { statusCode: 413 });
      if (usedBytes + size > MAX_STORAGE_MB * 1024 * 1024) throw Object.assign(new Error('Server upload storage quota would be exceeded.'), { statusCode: 507 });
      if (!writer.write(chunk)) await once(writer, 'drain');
    }
    writer.end();
    await once(writer, 'finish');
    if (size === 0) throw Object.assign(new Error('Uploaded file is empty.'), { statusCode: 400 });
    const meta = { id, filename: `${id}${extension}`, originalName: path.basename(decodeURIComponent(String(req.headers['x-file-name'] || 'video.mp4'))).slice(0, 180), size, createdAt: new Date().toISOString() };
    await writeFile(path.join(UPLOADS_META, `${id}.json`), JSON.stringify(meta, null, 2), { mode: 0o600 });
    return meta;
  } catch (error) {
    writer.destroy();
    await unlink(target).catch(() => undefined);
    throw error;
  }
}

const YOUTUBE_HOSTS = new Set(['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be']);

function validateYoutubeUrl(value) {
  let url;
  try { url = new URL(String(value || '')); } catch { throw Object.assign(new Error('Informe uma URL válida do YouTube.'), { statusCode: 400 }); }
  const host = url.hostname.toLowerCase();
  const allowedPath = host === 'youtu.be'
    ? /^\/[A-Za-z0-9_-]{6,20}\/?$/.test(url.pathname)
    : (url.pathname === '/watch'
      ? Boolean(url.searchParams.get('v'))
      : /^\/(shorts|live|embed)\/[A-Za-z0-9_-]{6,20}\/?$/.test(url.pathname));
  if (url.protocol !== 'https:' || !YOUTUBE_HOSTS.has(host) || !allowedPath || url.username || url.password || (url.port && url.port !== '443')) {
    throw Object.assign(new Error('Somente links HTTPS de vídeos individuais nos domínios oficiais do YouTube são aceitos.'), { statusCode: 400 });
  }
  return url.toString();
}

async function downloadYoutubeUpload(value) {
  const url = validateYoutubeUrl(value);
  const usedBytes = await directoryBytes(STORAGE);
  if (usedBytes >= MAX_STORAGE_MB * 1024 * 1024) throw Object.assign(new Error('Server storage quota is full.'), { statusCode: 507 });
  const id = randomUUID();
  const template = path.join(UPLOADS, `${id}.%(ext)s`);
  let stdout;
  try {
    ({ stdout } = await execFileAsync('yt-dlp', [
      '--no-playlist', '--no-warnings', '--restrict-filenames', '--max-filesize', `${MAX_UPLOAD_MB}M`,
      '--merge-output-format', 'mp4', '-f', 'bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b',
      '-o', template, '--print', 'after_move:filepath', url,
    ], { timeout: 20 * 60_000, maxBuffer: 8 * 1024 * 1024, encoding: 'utf8' }));
  } catch (error) {
    for (const name of await readdir(UPLOADS).catch(() => [])) {
      if (name.startsWith(`${id}.`)) await unlink(path.join(UPLOADS, name)).catch(() => undefined);
    }
    if (error?.code === 'ENOENT') throw Object.assign(new Error('yt-dlp não está instalado no servidor.'), { statusCode: 503 });
    throw Object.assign(new Error(`Falha ao obter vídeo do YouTube: ${safeError(error)}`), { statusCode: 502 });
  }
  const candidate = stdout.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).at(-1);
  if (!candidate) throw Object.assign(new Error('yt-dlp não informou o caminho do vídeo baixado.'), { statusCode: 502 });
  const file = path.resolve(candidate);
  if (!file.startsWith(`${UPLOADS}${path.sep}`)) throw Object.assign(new Error('O downloader retornou um caminho fora da pasta autorizada.'), { statusCode: 500 });
  const extension = path.extname(file).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(extension)) { await unlink(file).catch(() => undefined); throw Object.assign(new Error('O formato baixado não é compatível.'), { statusCode: 415 }); }
  const info = await stat(file);
  if (!info.isFile() || info.size <= 0 || info.size > MAX_UPLOAD_BYTES) { await unlink(file).catch(() => undefined); throw Object.assign(new Error('O vídeo baixado é vazio ou excede o limite de upload.'), { statusCode: 413 }); }
  await chmod(file, 0o600);
  const meta = { id, filename: path.basename(file), originalName: `youtube-${id.slice(0, 8)}${extension}`, size: info.size, createdAt: new Date().toISOString(), sourceUrl: url };
  await writeFile(path.join(UPLOADS_META, `${id}.json`), JSON.stringify(meta, null, 2), { mode: 0o600 });
  return meta;
}

class StdioMcpClient {
  constructor() {
    this.client = null;
    this.transport = null;
    this.ready = false;
    this.startPromise = null;
    this.toolNames = [];
  }

  async start() {
    if (this.ready && this.client) return;
    if (this.startPromise) return this.startPromise;

    this.startPromise = (async () => {
      if (!await fileExists(MCP_ENTRY)) {
        throw new Error('MCP server build is missing. Run "npm run build" from the project root before starting the web application.');
      }

      // Resolve the official SDK from mcp-server/node_modules. The root web
      // application intentionally has no duplicate SDK dependency tree.
      const requireFromMcp = createRequire(path.join(ROOT, 'mcp-server', 'package.json'));
      const clientEntry = requireFromMcp.resolve('@modelcontextprotocol/sdk/client/index.js');
      const stdioEntry = requireFromMcp.resolve('@modelcontextprotocol/sdk/client/stdio.js');
      const [{ Client }, { StdioClientTransport }] = await Promise.all([
        import(pathToFileURL(clientEntry).href),
        import(pathToFileURL(stdioEntry).href),
      ]);

      const env = Object.fromEntries(Object.entries(process.env).filter(([, value]) => value !== undefined));
      const transport = new StdioClientTransport({
        command: process.execPath,
        args: [MCP_ENTRY],
        cwd: ROOT,
        env: { ...env, VIDEO_VISION_HOME: STORAGE },
        stderr: 'ignore',
      });
      const client = new Client(
        { name: 'chatgpt-video-vision-web', version: '1.5.0' },
        { capabilities: {} },
      );

      try {
        await client.connect(transport);
        const discovered = await client.listTools();
        const names = (discovered.tools || []).map((tool) => tool.name).sort();
        const required = [...SAFE_TOOL_NAMES].sort();
        const missing = required.filter((name) => !names.includes(name));
        if (missing.length) {
          throw new Error(`The official MCP server is missing required tools: ${missing.join(', ')}.`);
        }
        this.client = client;
        this.transport = transport;
        this.toolNames = names;
        this.ready = true;
      } catch (error) {
        await client.close().catch(() => undefined);
        throw error;
      }
    })().finally(() => { this.startPromise = null; });

    return this.startPromise;
  }

  async callTool(name, args, timeoutMs = 20 * 60_000) {
    await this.start();
    if (!SAFE_TOOL_NAMES.has(name)) throw new Error('Unknown tool name.');
    const result = await this.client.callTool(
      { name, arguments: args },
      undefined,
      { timeout: timeoutMs },
    );
    if (result?.isError) {
      const message = (result.content || []).filter((item) => item.type === 'text').map((item) => item.text).join('\n');
      throw new Error(message || `MCP tool ${name} returned an error.`);
    }
    return result;
  }

  async close() {
    this.ready = false;
    this.toolNames = [];
    const client = this.client;
    this.client = null;
    this.transport = null;
    if (client) await client.close().catch(() => undefined);
  }
}

function getMcp() {
  if (!mcpClient) mcpClient = new StdioMcpClient();
  return mcpClient;
}

async function readUploadMeta(id) {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw Object.assign(new Error('Invalid upload identifier.'), { statusCode: 400 });
  const metaPath = path.join(UPLOADS_META, `${id}.json`);
  const meta = JSON.parse(await readFile(metaPath, 'utf8'));
  const file = path.resolve(UPLOADS, meta.filename);
  if (!file.startsWith(`${UPLOADS}${path.sep}`)) throw Object.assign(new Error('Invalid stored file path.'), { statusCode: 400 });
  return { meta, file };
}

async function persistJob(job) {
  await writeFile(path.join(JOBS, `${job.id}.json`), JSON.stringify(job, null, 2), { mode: 0o600 });
}

function updateJob(job, fields) {
  Object.assign(job, fields, { updatedAt: new Date().toISOString() });
  jobs.set(job.id, job);
  void persistJob(job);
}

function toolText(result) {
  return (result?.content || []).filter((item) => item.type === 'text').map((item) => item.text).join('\n\n');
}

function envAudioBackend() {
  if (process.env.OPENAI_API_KEY) return 'openai';
  if (process.env.GEMINI_API_KEY) return 'gemini-api';
  return null;
}

async function runJob(job) {
  const { meta, file } = await readUploadMeta(job.uploadId);
  const mcp = getMcp();
  updateJob(job, { status: 'processing', stage: 'configuring', progress: 5, message: 'Preparing video analysis.' });

  const requestedBackend = job.options.audioBackend || 'auto';
  const backend = requestedBackend === 'auto' ? envAudioBackend() : (requestedBackend === 'openai' && process.env.OPENAI_API_KEY ? 'openai' : requestedBackend === 'gemini-api' && process.env.GEMINI_API_KEY ? 'gemini-api' : null);
  const visualEnabled = Boolean(job.options.visualAnalysis && process.env.OPENAI_API_KEY);
  const notes = [];
  if (job.options.transcribe && !backend) notes.push(requestedBackend === 'auto' ? 'Speech transcription skipped: no OpenAI or Gemini API key is configured on the server.' : `Selected audio backend (${requestedBackend}) is unavailable because its server credential is not configured; transcription and sound tagging were skipped.`);
  if (backend === 'gemini-api' && job.options.transcribe && !job.options.soundEvents) notes.push('The preserved Gemini backend returns speech transcription and non-speech sound tags together; this original combined request cannot disable sound tags independently.');
  if (job.options.visualAnalysis && !process.env.OPENAI_API_KEY) notes.push('Visual model analysis skipped: OPENAI_API_KEY is not configured on the server. Frame extraction and structural analysis still run.');

  await mcp.callTool('video_configure', {
    ...(backend ? { backend } : {}),
    enable_index: true,
    max_frames: Math.min(100, Math.max(1, Number(job.options.maxFrames || 48))),
    frame_resolution: Math.min(2048, Math.max(128, Number(job.options.resolution || 512))),
    vision_model: job.options.visionModel || 'gpt-6.1-terra',
    vision_max_frames: Math.min(48, Math.max(1, Number(job.options.maxFrames || 24))),
    openai_audio_events_enabled: Boolean(job.options.soundEvents && backend === 'openai'),
  });

  updateJob(job, { stage: 'metadata', progress: 12, message: 'Reading video metadata.' });
  const infoResult = await mcp.callTool('video_info', { path: file });
  updateJob(job, { stage: 'structural-analysis', progress: 30, message: 'Analyzing scenes, silence, motion and technical characteristics.' });
  const analysisResult = await mcp.callTool('video_analyze', {
    path: file,
    filters: {
      scene_changes: true,
      black_intervals: true,
      silence: true,
      freeze: true,
      motion: true,
      blur: false,
      exposure: false,
      loudness: true,
      transcription: false,
    },
  });

  updateJob(job, { stage: 'frame-and-audio-analysis', progress: 58, message: 'Extracting frames and processing selected audio services.' });
  const watchResult = await mcp.callTool('video_watch', {
    path: file,
    fps: job.options.fps === 'auto' ? 'auto' : Number(job.options.fps || 0.5),
    resolution: Number(job.options.resolution || 512),
    frame_mode: 'descriptions',
    frame_format: 'jpeg',
    skip_audio: !(job.options.transcribe && backend),
    visual_analysis: visualEnabled,
    view_sample: Math.min(48, Math.max(1, Number(job.options.maxFrames || 24))),
  });

  updateJob(job, { stage: 'saving-results', progress: 92, message: 'Saving analysis results.' });
  const result = {
    source: { uploadId: meta.id, filename: meta.originalName, size: meta.size },
    info: infoResult,
    analysis: analysisResult,
    watch: watchResult,
    serviceAvailability: {
      transcription: Boolean(backend && job.options.transcribe),
      visualAnalysis: visualEnabled,
      openaiSoundEvents: Boolean(backend === 'openai' && job.options.soundEvents && job.options.transcribe),
      geminiSoundEvents: backend === 'gemini-api' && Boolean(job.options.transcribe),
    },
    notes,
  };
  const resultJson = JSON.stringify(result);
  const currentStorageBytes = await directoryBytes(STORAGE);
  if (currentStorageBytes + Buffer.byteLength(resultJson) > MAX_STORAGE_MB * 1024 * 1024) {
    throw new Error('The configured server storage quota would be exceeded by this analysis result. Increase MAX_STORAGE_MB or reduce frame count/resolution.');
  }
  await writeFile(path.join(RESULTS, `${job.id}.json`), resultJson, { mode: 0o600 });
  updateJob(job, { status: 'completed', stage: 'completed', progress: 100, message: 'Video analysis completed.', hasResult: true, completedAt: new Date().toISOString(), summary: { filename: meta.originalName, duration: parseDurationFromText(toolText(infoResult)), frameCount: (watchResult?.content || []).filter((x) => x.type === 'image').length, notes } });
}

function parseDurationFromText(text) {
  try {
    const parsed = JSON.parse(text);
    const value = parsed?.metadata?.duration_seconds ?? parsed?.duration_seconds;
    if (Number.isFinite(Number(value))) {
      const total = Math.max(0, Math.floor(Number(value)));
      const hours = Math.floor(total / 3600);
      const minutes = Math.floor((total % 3600) / 60);
      const seconds = total % 60;
      return [hours, minutes, seconds].map((part) => String(part).padStart(2, '0')).join(':');
    }
  } catch { /* metadata is displayed as provided by the MCP tool */ }
  return 'unknown';
}

async function processQueue() {
  if (workerRunning) return;
  workerRunning = true;
  try {
    while (queue.length) {
      const jobId = queue.shift();
      const job = jobs.get(jobId);
      if (!job) continue;
      try { await runJob(job); }
      catch (error) {
        updateJob(job, { status: 'failed', stage: 'failed', message: safeError(error), progress: job.progress || 0, completedAt: new Date().toISOString() });
      }
    }
  } finally { workerRunning = false; }
}

function parseCookieSecure(req) {
  return Boolean(req.socket.encrypted || String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https');
}

async function serveStatic(req, res, pathname) {
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const full = path.resolve(PUBLIC_DIR, relative);
  if (!full.startsWith(`${PUBLIC_DIR}${path.sep}`) && full !== path.join(PUBLIC_DIR, 'index.html')) return json(res, 404, { error: 'Not found.' });
  let content;
  try { content = await readFile(full); } catch { return json(res, 404, { error: 'Not found.' }); }
  const ext = path.extname(full).toLowerCase();
  const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml' };
  res.writeHead(200, {
    'Content-Type': types[ext] || 'application/octet-stream',
    'Content-Length': content.length,
    'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600',
    'X-Content-Type-Options': 'nosniff',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
    'Referrer-Policy': 'no-referrer',
  });
  res.end(content);
}

async function readStoredJob(id) {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw Object.assign(new Error('Invalid job identifier.'), { statusCode: 400 });
  if (jobs.has(id)) return jobs.get(id);
  try {
    const job = JSON.parse(await readFile(path.join(JOBS, `${id}.json`), 'utf8'));
    jobs.set(id, job);
    return job;
  } catch { throw Object.assign(new Error('Job not found.'), { statusCode: 404 }); }
}

async function handleApi(req, res, url) {
  const pathname = url.pathname;
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !assertSameOrigin(req)) return json(res, 403, { error: 'Cross-origin request rejected.' });

  if (pathname === '/api/health' && req.method === 'GET') {
    return json(res, 200, { status: 'ok', app: 'ChatGPT Video Vision', version: '1.5.0', node: process.versions.node, mcpBuilt: await fileExists(MCP_ENTRY), ffmpeg: await commandAvailable('ffmpeg'), ffprobe: await commandAvailable('ffprobe') });
  }

  if (pathname === '/api/login' && req.method === 'POST') {
    if (!loginRateAllowed(req)) return json(res, 429, { error: 'Too many login attempts. Try again later.' });
    const body = await readJson(req, 16 * 1024);
    const username = envRequired('APP_USERNAME');
    const password = envRequired('APP_PASSWORD', 12);
    if (!constantTimeStringEqual(body.username || '', username) || !constantTimeStringEqual(body.password || '', password)) {
      return json(res, 401, { error: 'Invalid username or password.' });
    }
    const cookie = `cvv_session=${issueSession(username)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL_SECONDS}${parseCookieSecure(req) ? '; Secure' : ''}`;
    return json(res, 200, { ok: true }, { 'Set-Cookie': cookie });
  }
  if (pathname === '/api/logout' && req.method === 'POST') {
    const token = (req.headers.cookie || '').split(';').map((x) => x.trim()).find((x) => x.startsWith('cvv_session='))?.slice('cvv_session='.length) || '';
    try { const payload = token.split('.')[0]; const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')); activeSessions.delete(data.nonce); } catch { /* invalid cookie */ }
    return json(res, 200, { ok: true }, { 'Set-Cookie': 'cvv_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
  }

  if (!validSession(req)) return json(res, 401, { error: 'Authentication required.' });
  if (pathname === '/api/mcp/status' && req.method === 'GET') {
    const client = getMcp();
    await client.start();
    return json(res, 200, { connected: true, transport: 'official-sdk-stdio', tools: client.toolNames });
  }
  if (pathname === '/api/status' && req.method === 'GET') {
    const backend = envAudioBackend();
    return json(res, 200, {
      authenticated: true,
      app: 'ChatGPT Video Vision',
      node: process.versions.node,
      api: { openai: Boolean(process.env.OPENAI_API_KEY), gemini: Boolean(process.env.GEMINI_API_KEY), audioBackend: backend, mcpTokenConfigured: Boolean(process.env.MCP_AUTH_TOKEN) },
      limits: { maxUploadMb: MAX_UPLOAD_MB, maxStorageMb: MAX_STORAGE_MB, maxPendingJobs: MAX_PENDING_JOBS, retentionHours: RETENTION_HOURS },
      tools: ['video_watch', 'video_analyze', 'video_detail', 'video_info', 'video_configure', 'video_setup'],
    });
  }

  if (pathname === '/api/upload' && req.method === 'POST') {
    const meta = await storeUpload(req);
    return json(res, 201, { upload: meta });
  }
  if (pathname === '/api/youtube' && req.method === 'POST') {
    const body = await readJson(req, 16 * 1024);
    const upload = await downloadYoutubeUpload(body.url);
    return json(res, 201, { upload });
  }

  if (pathname === '/api/jobs' && req.method === 'POST') {
    const body = await readJson(req, 32 * 1024);
    if (queue.length >= MAX_PENDING_JOBS) return json(res, 429, { error: `Processing queue is full (limit ${MAX_PENDING_JOBS}). Try again after a job finishes.` });
    if (typeof body.uploadId !== 'string') return json(res, 400, { error: 'uploadId is required.' });
    await readUploadMeta(body.uploadId);
    const options = {
      transcribe: body.transcribe !== false,
      visualAnalysis: body.visualAnalysis !== false,
      soundEvents: body.soundEvents !== false,
      fps: ['auto', 0.1, 0.2, 0.5, 1, 2].includes(body.fps) ? body.fps : 'auto',
      resolution: [256, 384, 512, 640, 768, 1024].includes(Number(body.resolution)) ? Number(body.resolution) : 512,
      maxFrames: Math.min(48, Math.max(1, Number(body.maxFrames || 24))),
      visionModel: ['gpt-6.1-terra', 'gpt-6-luna', 'gpt-6.1-sol', 'gpt-6-astra'].includes(body.visionModel) ? body.visionModel : 'gpt-6.1-terra',
      audioBackend: ['auto', 'openai', 'gemini-api'].includes(body.audioBackend) ? body.audioBackend : 'auto',
    };
    const job = { id: randomUUID(), uploadId: body.uploadId, status: 'queued', stage: 'queued', progress: 0, message: 'Waiting for the processing worker.', options, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), hasResult: false };
    jobs.set(job.id, job);
    await persistJob(job);
    queue.push(job.id);
    void processQueue();
    return json(res, 202, { job });
  }

  if (pathname === '/api/jobs' && req.method === 'GET') {
    const list = [...jobs.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 30).map(({ id, status, stage, progress, message, createdAt, updatedAt, summary, hasResult }) => ({ id, status, stage, progress, message, createdAt, updatedAt, summary, hasResult }));
    return json(res, 200, { jobs: list });
  }

  const streamMatch = pathname.match(/^\/api\/uploads\/([0-9a-f-]{36})\/stream$/i);
  if (streamMatch && req.method === 'GET') {
    const { meta, file } = await readUploadMeta(streamMatch[1]);
    const info = await stat(file);
    const extension = path.extname(file).toLowerCase();
    const mime = ({ '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm', '.mkv': 'video/x-matroska', '.avi': 'video/x-msvideo', '.mpeg': 'video/mpeg', '.mpg': 'video/mpeg', '.wmv': 'video/x-ms-wmv', '.flv': 'video/x-flv', '.3gp': 'video/3gpp' })[extension] || 'application/octet-stream';
    const range = req.headers.range;
    if (range) {
      const match = range.match(/^bytes=(\d*)-(\d*)$/);
      if (!match) return json(res, 416, { error: 'Invalid byte range.' }, { 'Content-Range': `bytes */${info.size}` });
      let start = match[1] ? Number(match[1]) : 0;
      let end = match[2] ? Number(match[2]) : info.size - 1;
      if (!match[1] && match[2]) start = Math.max(0, info.size - Number(match[2]));
      end = Math.min(end, info.size - 1);
      if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start > end || start >= info.size) return json(res, 416, { error: 'Requested byte range is not satisfiable.' }, { 'Content-Range': `bytes */${info.size}` });
      res.writeHead(206, { 'Content-Type': mime, 'Content-Length': end - start + 1, 'Accept-Ranges': 'bytes', 'Content-Range': `bytes ${start}-${end}/${info.size}`, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
      return createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { 'Content-Type': mime, 'Content-Length': info.size, 'Accept-Ranges': 'bytes', 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' });
    return createReadStream(file).pipe(res);
  }

  const detailMatch = pathname.match(/^\/api\/jobs\/([0-9a-f-]{36})\/detail$/i);
  if (detailMatch && req.method === 'POST') {
    const job = await readStoredJob(detailMatch[1]);
    if (job.status !== 'completed') return json(res, 409, { error: 'The video job must be completed before querying a moment.' });
    const body = await readJson(req, 16 * 1024);
    const time = String(body.time || '');
    if (!/^\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?$/.test(time)) return json(res, 400, { error: 'time must use HH:MM:SS[.mmm].' });
    const seconds = time.split(':').reduce((acc, part) => acc * 60 + Number(part), 0);
    const endSeconds = seconds + Math.min(30, Math.max(1, Number(body.duration || 5)));
    const fmt = (n) => { const h = Math.floor(n / 3600); const m = Math.floor((n % 3600) / 60); const s = n % 60; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${s.toFixed(3).padStart(6, '0')}`; };
    const { file } = await readUploadMeta(job.uploadId);
    const result = await getMcp().callTool('video_detail', {
      path: file,
      segments: [{ start: fmt(seconds), end: fmt(endSeconds), fps: 2, resolution: job.options.resolution }],
      view_sample: 16,
      visual_analysis: Boolean(job.options.visualAnalysis && process.env.OPENAI_API_KEY),
    });
    return json(res, 200, { result });
  }

  const jobMatch = pathname.match(/^\/api\/jobs\/([0-9a-f-]{36})$/i);
  if (jobMatch && req.method === 'GET') {
    const job = await readStoredJob(jobMatch[1]);
    return json(res, 200, { job });
  }

  const resultMatch = pathname.match(/^\/api\/jobs\/([0-9a-f-]{36})\/result$/i);
  if (resultMatch && req.method === 'GET') {
    const job = await readStoredJob(resultMatch[1]);
    if (!job.hasResult) return json(res, 409, { error: 'Result is not available yet.' });
    const payload = await readFile(path.join(RESULTS, `${job.id}.json`), 'utf8');
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    return res.end(payload);
  }

  if (pathname === '/api/settings' && req.method === 'GET') {
    return json(res, 200, {
      visionModel: 'gpt-6.1-terra',
      availableAudioBackends: [process.env.OPENAI_API_KEY ? 'openai' : null, process.env.GEMINI_API_KEY ? 'gemini-api' : null].filter(Boolean),
      keysConfigured: { openai: Boolean(process.env.OPENAI_API_KEY), gemini: Boolean(process.env.GEMINI_API_KEY) },
      secretValuesAreNotExposed: true,
    });
  }

  if (pathname === '/api/settings' && req.method === 'PATCH') {
    const body = await readJson(req, 16 * 1024);
    const allowed = {};
    if (body.frame_resolution !== undefined) allowed.frame_resolution = Math.min(2048, Math.max(128, Number(body.frame_resolution)));
    if (body.max_frames !== undefined) allowed.max_frames = Math.min(1000, Math.max(1, Number(body.max_frames)));
    if (body.default_fps !== undefined) allowed.default_fps = body.default_fps === 'auto' ? 'auto' : Math.min(10, Math.max(0.05, Number(body.default_fps)));
    if (body.vision_model !== undefined && ['gpt-6.1-terra', 'gpt-6-luna', 'gpt-6.1-sol', 'gpt-6-astra'].includes(body.vision_model)) allowed.vision_model = body.vision_model;
    if (body.vision_detail !== undefined && ['low', 'high', 'auto'].includes(body.vision_detail)) allowed.vision_detail = body.vision_detail;
    const result = await getMcp().callTool('video_configure', allowed);
    return json(res, 200, { ok: true, result });
  }

  if (pathname === '/api/setup' && req.method === 'GET') {
    const backend = envAudioBackend() || 'openai';
    const result = await getMcp().callTool('video_setup', { backend, whisper_engine: 'cpp', whisper_model: 'auto' });
    return json(res, 200, { result });
  }

  if (pathname === '/api/tools' && req.method === 'GET') {
    return json(res, 200, { tools: [...SAFE_TOOL_NAMES] });
  }

  return json(res, 404, { error: 'API route not found.' });
}

async function fileExists(file) { try { await stat(file); return true; } catch { return false; } }
async function commandAvailable(command) {
  try {
    const child = spawn(command, ['-version'], { stdio: 'ignore' });
    return await new Promise((resolve) => { child.once('error', () => resolve(false)); child.once('exit', (code) => resolve(code === 0)); });
  } catch { return false; }
}

async function restorePersistedJobs() {
  for (const name of await readdir(JOBS).catch(() => [])) {
    if (!name.endsWith('.json')) continue;
    try {
      const job = JSON.parse(await readFile(path.join(JOBS, name), 'utf8'));
      if (!job || typeof job.id !== 'string') continue;
      if (job.status === 'queued' || job.status === 'processing') {
        Object.assign(job, { status: 'failed', stage: 'interrupted', progress: job.progress || 0, message: 'O servidor foi reiniciado durante esta tarefa. Inicie uma nova análise para continuar.', updatedAt: new Date().toISOString() });
        await persistJob(job);
      }
      jobs.set(job.id, job);
    } catch { /* Ignore a single malformed job record; keep the service available. */ }
  }
}

async function cleanupExpired() {
  const cutoff = Date.now() - RETENTION_HOURS * 60 * 60_000;
  for (const folder of [UPLOADS, UPLOADS_META, JOBS, RESULTS]) {
    for (const name of await readdir(folder).catch(() => [])) {
      const file = path.join(folder, name);
      const info = await stat(file).catch(() => null);
      if (info?.isFile() && info.mtimeMs < cutoff) await unlink(file).catch(() => undefined);
    }
  }
}

async function main() {
  envRequired('APP_USERNAME');
  const appPassword = envRequired('APP_PASSWORD', 12);
  const sessionSecret = envRequired('SESSION_SECRET', 32);
  if (/CHANGE_ME|replace|example/i.test(appPassword) || /CHANGE_ME|replace|example/i.test(sessionSecret)) {
    throw new Error('Replace all example APP_PASSWORD and SESSION_SECRET values before starting the server.');
  }
  if (process.env.MCP_AUTH_TOKEN && /CHANGE_ME|replace|example/i.test(process.env.MCP_AUTH_TOKEN)) {
    console.warn('MCP_AUTH_TOKEN is an example value; remote MCP will remain disabled.');
  }
  for (const folder of [STORAGE, UPLOADS, JOBS, RESULTS, UPLOADS_META]) await mkdir(folder, { recursive: true, mode: 0o700 });
  await cleanupExpired();
  await restorePersistedJobs();
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
      if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
      if (url.pathname === '/mcp' && ['POST', 'GET', 'DELETE'].includes(req.method)) {
        const token = process.env.MCP_AUTH_TOKEN;
        if (!token || token.length < 24 || token.includes('CHANGE_ME') || !constantTimeStringEqual((req.headers.authorization || '').replace(/^Bearer\s+/i, ''), token)) return json(res, 401, { error: 'Remote MCP requires a valid bearer token.' });
        const handler = await import('../mcp-server/dist/mcp-http.js');
        return await handler.handleMcpHttpRequest(req, res);
      }
      return await serveStatic(req, res, url.pathname);
    } catch (error) {
      if (!res.headersSent) json(res, error.statusCode || 500, { error: safeError(error) });
      else res.destroy();
    }
  });
  server.headersTimeout = 65_000;
  server.requestTimeout = Math.max(120_000, Number(process.env.UPLOAD_TIMEOUT_MS || 30 * 60_000));
  server.keepAliveTimeout = 5_000;
  server.listen(PORT, '0.0.0.0', () => console.log(`ChatGPT Video Vision listening on port ${PORT}`));
  setInterval(() => void cleanupExpired(), 60 * 60_000).unref();
  const shutdown = async () => { await getMcp().close(); server.close(() => process.exit(0)); setTimeout(() => process.exit(1), 10_000).unref(); };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch((error) => { console.error(safeError(error)); process.exit(1); });
}

export { StdioMcpClient, storeUpload, downloadYoutubeUpload, validateYoutubeUrl, issueSession, validSession, safeError, directoryBytes, STORAGE };
