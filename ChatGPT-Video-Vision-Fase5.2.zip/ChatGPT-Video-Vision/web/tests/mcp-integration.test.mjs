import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { execFileSync, spawn } from 'node:child_process';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { once } from 'node:events';
import { pathToFileURL } from 'node:url';
import { randomInt } from 'node:crypto';

const ROOT = path.resolve('.');
const MCP_PACKAGE = path.join(ROOT, 'mcp-server', 'package.json');
const MCP_DIST = path.join(ROOT, 'mcp-server', 'dist', 'index.js');
const MCP_HTTP_DIST = path.join(ROOT, 'mcp-server', 'dist', 'mcp-http.js');
const REQUIRED = [
  'video_analyze', 'video_configure', 'video_detail',
  'video_info', 'video_setup', 'video_watch',
];
const TEST_USERNAME = 'phase4-tester';
const TEST_PASSWORD = 'phase4-temporary-test-password';
const TEST_SESSION_SECRET = 'phase4-session-secret-that-is-longer-than-32-characters';
const TEST_MCP_TOKEN = 'phase4-mcp-test-token-32-characters-long';

function requireMcpPackage() {
  return createRequire(MCP_PACKAGE);
}

async function importMcpExport(specifier) {
  const req = requireMcpPackage();
  return import(pathToFileURL(req.resolve(specifier)).href);
}

async function makeVisibleAudioVideo(file) {
  execFileSync('ffmpeg', [
    '-hide_banner', '-loglevel', 'error', '-y',
    '-f', 'lavfi', '-i', 'testsrc2=size=320x240:rate=25:duration=6',
    '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100:duration=6',
    '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-shortest', '-movflags', '+faststart', file,
  ], { stdio: 'inherit' });
}

async function waitForJob(base, cookie, jobId, timeoutMs = 90_000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const response = await fetch(`${base}/api/jobs/${jobId}`, { headers: { Cookie: cookie } });
    assert.equal(response.status, 200);
    const { job } = await response.json();
    if (job.status === 'completed' || job.status === 'failed') return job;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error(`Timed out waiting for web job ${jobId}`);
}

const canRunOfficialMcp = Number(process.versions.node.split('.')[0]) >= 24
  && existsSync(MCP_DIST) && existsSync(MCP_HTTP_DIST);

test('official MCP stdio + web worker + Streamable HTTP session integration', async (t) => {
  if (!canRunOfficialMcp) {
    t.skip('Requires Node.js 24+, a successful MCP build, and installed @modelcontextprotocol/sdk dependencies.');
    return;
  }

  const temp = await mkdtemp(path.join(os.tmpdir(), 'cvv-phase4-e2e-'));
  const fixture = path.join(temp, 'visible-audio.mp4');
  const port = 8400 + randomInt(800);
  const base = `http://127.0.0.1:${port}`;
  const storage = path.join(temp, 'storage');
  const serverPath = path.join(ROOT, 'web', 'server.mjs');
  const server = spawn(process.execPath, [serverPath], {
    cwd: ROOT,
    env: {
      ...process.env,
      PORT: String(port),
      VIDEO_VISION_HOME: storage,
      APP_USERNAME: TEST_USERNAME,
      APP_PASSWORD: TEST_PASSWORD,
      SESSION_SECRET: TEST_SESSION_SECRET,
      MCP_AUTH_TOKEN: TEST_MCP_TOKEN,
      MAX_UPLOAD_MB: '16',
      MAX_STORAGE_MB: '128',
      MAX_PENDING_JOBS: '2',
      RETENTION_HOURS: '2',
      // Ensure no external model API is called by this test.
      OPENAI_API_KEY: '',
      GEMINI_API_KEY: '',
    },
    stdio: ['ignore', 'ignore', 'pipe'],
  });
  let stdioClient;
  let httpClient;
  let failureText = '';
  server.stderr.setEncoding('utf8');
  server.stderr.on('data', (chunk) => { failureText = `${failureText}${chunk}`.slice(-4000); });

  try {
    await makeVisibleAudioVideo(fixture);
    const fixtureBytes = await readFile(fixture);

    let ready = false;
    for (let i = 0; i < 80; i++) {
      if (server.exitCode !== null) throw new Error(`Web server exited early: ${failureText}`);
      try {
        const response = await fetch(`${base}/api/health`);
        if (response.ok) {
          const health = await response.json();
          assert.equal(health.mcpBuilt, true);
          assert.equal(health.ffmpeg, true);
          assert.equal(health.ffprobe, true);
          ready = true;
          break;
        }
      } catch { /* server is starting */ }
      await new Promise((resolve) => setTimeout(resolve, 150));
    }
    assert.equal(ready, true, `web server did not start: ${failureText}`);

    // Browser/web login and protected API.
    const login = await fetch(`${base}/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Origin: base },
      body: JSON.stringify({ username: TEST_USERNAME, password: TEST_PASSWORD }),
    });
    assert.equal(login.status, 200);
    const cookie = login.headers.get('set-cookie').split(';')[0];

    // The web application's own bridge must use the SDK Client + StdioClientTransport.
    const mcpStatusResponse = await fetch(`${base}/api/mcp/status`, { headers: { Cookie: cookie } });
    assert.equal(mcpStatusResponse.status, 200, await mcpStatusResponse.text());
    const mcpStatus = await mcpStatusResponse.json();
    assert.equal(mcpStatus.connected, true);
    assert.equal(mcpStatus.transport, 'official-sdk-stdio');
    assert.deepEqual(mcpStatus.tools, REQUIRED);

    // Upload a visible moving test pattern plus a real audio stream.
    const upload = await fetch(`${base}/api/upload`, {
      method: 'POST',
      headers: {
        Cookie: cookie, Origin: base, 'Content-Type': 'application/octet-stream',
        'X-File-Name': encodeURIComponent('visible-audio.mp4'),
        'Content-Length': String(fixtureBytes.length),
      },
      body: fixtureBytes,
    });
    assert.equal(upload.status, 201, await upload.text());
    const { upload: uploaded } = await upload.json();

    // Queue a real no-credential analysis through the web app's official MCP client.
    const queued = await fetch(`${base}/api/jobs`, {
      method: 'POST',
      headers: { Cookie: cookie, Origin: base, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uploadId: uploaded.id,
        transcribe: false,
        visualAnalysis: false,
        soundEvents: false,
        fps: 1,
        resolution: 256,
        maxFrames: 4,
      }),
    });
    assert.equal(queued.status, 202, await queued.text());
    const { job: initialJob } = await queued.json();
    const completed = await waitForJob(base, cookie, initialJob.id);
    assert.equal(completed.status, 'completed', completed.message);
    assert.equal(completed.hasResult, true);
    assert.equal(completed.summary.frameCount > 0, true);

    const resultResponse = await fetch(`${base}/api/jobs/${initialJob.id}/result`, { headers: { Cookie: cookie } });
    assert.equal(resultResponse.status, 200);
    const result = await resultResponse.json();
    const infoText = result.info.content.filter((part) => part.type === 'text').map((part) => part.text).join('\n');
    assert.match(infoText, /duration_seconds/);
    assert.match(infoText, /has_audio.*true|true.*has_audio/s);
    const watchImages = result.watch.content.filter((part) => part.type === 'image');
    assert.ok(watchImages.length > 0, 'web result should include real extracted frame images');
    const analysisText = result.analysis.content.filter((part) => part.type === 'text').map((part) => part.text).join('\n');
    assert.match(analysisText, /"analysis"/);

    // Query a timestamp via web API; this again traverses official MCP tools/call.
    const detailResponse = await fetch(`${base}/api/jobs/${initialJob.id}/detail`, {
      method: 'POST',
      headers: { Cookie: cookie, Origin: base, 'Content-Type': 'application/json' },
      body: JSON.stringify({ time: '00:00:01.000', duration: 2 }),
    });
    assert.equal(detailResponse.status, 200, await detailResponse.text());
    const detail = await detailResponse.json();
    assert.ok(detail.result.content.some((part) => part.type === 'image'));

    const historyResponse = await fetch(`${base}/api/jobs`, { headers: { Cookie: cookie } });
    assert.equal(historyResponse.status, 200);
    const history = await historyResponse.json();
    assert.ok(history.jobs.some((job) => job.id === initialJob.id && job.status === 'completed'));

    // Independently test official SDK stdio discovery + callTool at the protocol level.
    const { Client } = await importMcpExport('@modelcontextprotocol/sdk/client/index.js');
    const { StdioClientTransport } = await importMcpExport('@modelcontextprotocol/sdk/client/stdio.js');
    stdioClient = new Client({ name: 'phase4-stdio-probe', version: '1.0.0' });
    const stdioTransport = new StdioClientTransport({
      command: process.execPath,
      args: [MCP_DIST],
      cwd: ROOT,
      env: { ...process.env, VIDEO_VISION_HOME: storage, OPENAI_API_KEY: '', GEMINI_API_KEY: '' },
      stderr: 'ignore',
    });
    await stdioClient.connect(stdioTransport);
    const stdioCatalog = await stdioClient.listTools();
    assert.deepEqual(stdioCatalog.tools.map((tool) => tool.name).sort(), REQUIRED);
    const stdioInfo = await stdioClient.callTool({ name: 'video_info', arguments: { path: path.join(storage, 'uploads', uploaded.filename) } });
    assert.equal(stdioInfo.isError, false);
    assert.match(stdioInfo.content.map((part) => part.text || '').join('\n'), /duration_seconds/);

    // Test authenticated official Streamable HTTP and stateful session reuse.
    const { StreamableHTTPClientTransport } = await importMcpExport('@modelcontextprotocol/sdk/client/streamableHttp.js');
    httpClient = new Client({ name: 'phase4-http-probe', version: '1.0.0' });
    const httpTransport = new StreamableHTTPClientTransport(new URL(`${base}/mcp`), {
      requestInit: { headers: { Authorization: `Bearer ${TEST_MCP_TOKEN}` } },
    });
    await httpClient.connect(httpTransport);
    const httpCatalog = await httpClient.listTools();
    assert.deepEqual(httpCatalog.tools.map((tool) => tool.name).sort(), REQUIRED);
    for (let i = 0; i < 2; i++) {
      const httpInfo = await httpClient.callTool({ name: 'video_info', arguments: { path: path.join(storage, 'uploads', uploaded.filename) } });
      assert.equal(httpInfo.isError, false, `HTTP MCP call ${i + 1} failed`);
      assert.match(httpInfo.content.map((part) => part.text || '').join('\n'), /duration_seconds/);
    }

    console.log(JSON.stringify({
      status: 'PASS',
      node: process.version,
      officialStdioMcp: { tools: stdioCatalog.tools.map((tool) => tool.name), videoInfoCall: 'passed' },
      officialStreamableHttpMcp: { tools: httpCatalog.tools.map((tool) => tool.name), repeatedCalls: 2 },
      webWorker: { jobStatus: completed.status, frames: watchImages.length, detailFrames: detail.result.content.filter((part) => part.type === 'image').length },
      fixture: { durationSeconds: 6, video: 'FFmpeg testsrc2', audio: '440 Hz sine AAC' },
      externalAi: 'not called; API credentials are blank in the test process',
    }, null, 2));
  } finally {
    await httpClient?.close().catch(() => undefined);
    await stdioClient?.close().catch(() => undefined);
    if (server.exitCode === null && server.signalCode === null) {
      server.kill('SIGTERM');
      await once(server, 'exit').catch(() => undefined);
    }
    await rm(temp, { recursive: true, force: true });
  }
});
