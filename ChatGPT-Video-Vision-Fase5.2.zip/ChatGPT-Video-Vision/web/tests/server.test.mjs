import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { randomInt } from 'node:crypto';
import { spawn } from 'node:child_process';
import { once } from 'node:events';

let tempHome;
let helpers;

before(async () => {
  tempHome = await mkdtemp(path.join(tmpdir(), 'cvv-web-test-'));
  process.env.VIDEO_VISION_HOME = tempHome;
  process.env.SESSION_SECRET = 'test-session-secret-that-is-longer-than-32-chars';
  process.env.MAX_UPLOAD_MB = '8';
  helpers = await import('../server.mjs');
  for (const folder of ['uploads', 'upload-meta', 'jobs', 'results']) await mkdir(path.join(tempHome, folder), { recursive: true });
});

after(async () => {
  await rm(tempHome, { recursive: true, force: true });
});

test('session signatures are valid only for active issued sessions', () => {
  const token = helpers.issueSession('tester');
  assert.equal(helpers.validSession({ headers: { cookie: `cvv_session=${token}` } }), true);
  assert.equal(helpers.validSession({ headers: { cookie: 'cvv_session=forged.invalid' } }), false);
});

test('YouTube URL validation allows official HTTPS links and rejects arbitrary hosts', () => {
  assert.match(helpers.validateYoutubeUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ'), /^https:/);
  assert.match(helpers.validateYoutubeUrl('https://youtu.be/dQw4w9WgXcQ'), /^https:/);
  assert.match(helpers.validateYoutubeUrl('https://www.youtube.com/shorts/dQw4w9WgXcQ'), /^https:/);
  assert.match(helpers.validateYoutubeUrl('https://www.youtube.com/live/dQw4w9WgXcQ'), /^https:/);
  assert.match(helpers.validateYoutubeUrl('https://www.youtube.com/embed/dQw4w9WgXcQ'), /^https:/);
  assert.throws(() => helpers.validateYoutubeUrl('http://youtube.com/watch?v=x'), /HTTPS/);
  assert.throws(() => helpers.validateYoutubeUrl('https://127.0.0.1/admin'), /HTTPS/);
  assert.throws(() => helpers.validateYoutubeUrl('https://youtube.com.example.org/watch?v=x'), /HTTPS/);
});

test('stored uploads use generated private names and reject unsupported extensions', async () => {
  const chunks = [Buffer.from('fake-video-bytes')];
  const req = {
    headers: { 'x-file-name': encodeURIComponent('example.mp4'), 'content-length': String(chunks[0].length) },
    async *[Symbol.asyncIterator]() { for (const chunk of chunks) yield chunk; },
  };
  const meta = await helpers.storeUpload(req);
  assert.match(meta.id, /^[0-9a-f-]{36}$/i);
  assert.equal(meta.originalName, 'example.mp4');
  const stored = path.join(tempHome, 'uploads', meta.filename);
  assert.equal((await stat(stored)).size, chunks[0].length);
  assert.deepEqual(await readFile(stored), chunks[0]);
  const badReq = {
    headers: { 'x-file-name': encodeURIComponent('file.exe'), 'content-length': '1' },
    async *[Symbol.asyncIterator]() { yield Buffer.from('x'); },
  };
  await assert.rejects(() => helpers.storeUpload(badReq), /Unsupported video file extension/);
});

test('web server enforces login and accepts authenticated Android-style raw uploads', async (t) => {
  const port = 8200 + randomInt(1000);
  const serverPath = path.resolve('web/server.mjs');
  const fixture = await readFile(path.resolve('mcp-server/tests/fixtures/test-3s.mp4'));
  const child = spawn(process.execPath, [serverPath], {
    env: {
      ...process.env,
      PORT: String(port),
      VIDEO_VISION_HOME: path.join(tempHome, 'running-server'),
      APP_USERNAME: 'tester',
      APP_PASSWORD: 'test-password-2026',
      SESSION_SECRET: 'test-session-secret-that-is-longer-than-32-chars',
      MAX_UPLOAD_MB: '8',
    },
    stdio: ['ignore', 'ignore', 'pipe'],
  });
  t.after(async () => { child.kill('SIGTERM'); await once(child, 'exit').catch(() => undefined); });
  const base = `http://127.0.0.1:${port}`;
  let ready = false;
  for (let i = 0; i < 40; i++) {
    try { const r = await fetch(`${base}/api/health`); if (r.ok) { ready = true; break; } } catch { /* starting */ }
    await new Promise((resolve) => setTimeout(resolve, 150));
  }
  assert.equal(ready, true, 'web service should start');

  const health = await (await fetch(`${base}/api/health`)).json();
  assert.equal(health.app, 'ChatGPT Video Vision');
  assert.equal(health.ffmpeg, true);
  assert.equal(health.ffprobe, true);

  const denied = await fetch(`${base}/api/status`);
  assert.equal(denied.status, 401);
  const mcpStatusDenied = await fetch(`${base}/api/mcp/status`);
  assert.equal(mcpStatusDenied.status, 401, 'MCP process status must not be accessible before authentication');

  const login = await fetch(`${base}/api/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Origin: base },
    body: JSON.stringify({ username: 'tester', password: 'test-password-2026' }),
  });
  assert.equal(login.status, 200);
  const cookie = login.headers.get('set-cookie').split(';')[0];

  const status = await fetch(`${base}/api/status`, { headers: { Cookie: cookie } });
  assert.equal(status.status, 200);
  const statusBody = await status.json();
  assert.equal(statusBody.tools.length, 6);

  const upload = await fetch(`${base}/api/upload`, {
    method: 'POST',
    headers: { Cookie: cookie, Origin: base, 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent('fixture.mp4'), 'Content-Length': String(fixture.length) },
    body: fixture,
  });
  assert.equal(upload.status, 201);
  const uploadBody = await upload.json();
  assert.equal(uploadBody.upload.originalName, 'fixture.mp4');
  assert.equal(uploadBody.upload.size, fixture.length);

  const streamed = await fetch(`${base}/api/uploads/${uploadBody.upload.id}/stream`, { headers: { Cookie: cookie, Range: 'bytes=0-15' } });
  assert.equal(streamed.status, 206);
  assert.equal(streamed.headers.get('content-range'), `bytes 0-15/${fixture.length}`);
  assert.equal((await streamed.arrayBuffer()).byteLength, 16);

  const unauthorizedStream = await fetch(`${base}/api/uploads/${uploadBody.upload.id}/stream`);
  assert.equal(unauthorizedStream.status, 401);
});
