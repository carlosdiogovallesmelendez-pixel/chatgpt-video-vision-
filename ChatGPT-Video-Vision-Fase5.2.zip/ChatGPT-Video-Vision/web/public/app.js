const $ = (id) => document.getElementById(id);
let currentJobId = null;
let pollTimer = null;
let currentResult = null;

async function api(path, options = {}) {
  const response = await fetch(path, { credentials: 'same-origin', ...options, headers: { ...(options.headers || {}) } });
  const text = await response.text();
  let body = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { error: text || 'Invalid response.' }; }
  if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
  return body;
}

function showApp(visible) {
  $('loginView').classList.toggle('hidden', visible);
  $('appView').classList.toggle('hidden', !visible);
  $('logoutButton').classList.toggle('hidden', !visible);
}

function escapeText(value) { return String(value ?? ''); }
function toolText(result) { return (result?.content || []).filter((item) => item.type === 'text').map((item) => item.text).join('\n\n'); }
function textBlock(content, heading) {
  const all = (content || []).filter((item) => item.type === 'text').map((item) => item.text);
  return all.find((text) => text.includes(heading)) || all.join('\n\n');
}
function safePre(value) { const pre = document.createElement('pre'); pre.textContent = escapeText(value); return pre; }

async function refreshStatus() {
  try {
    const data = await api('/api/status');
    $('systemStatus').textContent = data.api.openai || data.api.gemini ? 'Servidor conectado · API disponível' : 'Servidor conectado · sem APIs externas';
    $('apiNotice').textContent = `Limite de upload: ${data.limits.maxUploadMb} MB. ${data.api.openai ? 'OpenAI configurada.' : 'OpenAI não configurada.'} ${data.api.gemini ? 'Gemini configurado.' : 'Gemini não configurado.'}`;
  } catch (error) {
    $('systemStatus').textContent = 'Servidor indisponível';
    $('apiNotice').textContent = error.message;
  }
}

$('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('loginError').textContent = '';
  try {
    await api('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: $('username').value, password: $('password').value }) });
    $('password').value = '';
    showApp(true);
    await refreshStatus();
    await loadHistory();
  } catch (error) { $('loginError').textContent = error.message; }
});

$('logoutButton').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' }).catch(() => undefined);
  showApp(false);
});

$('videoFile').addEventListener('change', () => {
  const file = $('videoFile').files[0];
  $('fileName').textContent = file ? `${file.name} · ${(file.size / 1024 / 1024).toFixed(1)} MB` : 'Nenhum arquivo selecionado';
  $('startButton').disabled = !file;
  $('uploadError').textContent = '';
});

function uploadFile(file) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/upload');
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name));
    $('uploadProgress').classList.remove('hidden');
    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable) $('uploadProgressBar').style.width = `${Math.round(event.loaded / event.total * 100)}%`;
    });
    xhr.addEventListener('load', () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch { /* handled below */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data.upload);
      else reject(new Error(data.error || `Falha no upload (${xhr.status}).`));
    });
    xhr.addEventListener('error', () => reject(new Error('Falha de rede durante o upload.')));
    xhr.addEventListener('abort', () => reject(new Error('Upload interrompido.')));
    xhr.send(file);
  });
}

async function submitJob(upload) {
  const body = await api('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uploadId: upload.id, visualAnalysis: $('visualAnalysis').checked, transcribe: $('transcribe').checked, soundEvents: $('soundEvents').checked, audioBackend: $('audioBackend').value, visionModel: $('visionModel').value, resolution: Number($('resolution').value), fps: $('fps').value === 'auto' ? 'auto' : Number($('fps').value), maxFrames: Number($('maxFrames').value) }) });
  currentJobId = body.job.id;
  $('jobError').textContent = '';
  await pollJob(currentJobId);
  await loadHistory();
}

$('startButton').addEventListener('click', async () => {
  const file = $('videoFile').files[0];
  if (!file) return;
  $('startButton').disabled = true;
  $('uploadError').textContent = '';
  $('uploadProgressBar').style.width = '0%';
  $('jobPanel').classList.remove('hidden');
  $('resultPanel').classList.add('hidden');
  try {
    const upload = await uploadFile(file);
    await submitJob(upload);
  } catch (error) { $('uploadError').textContent = error.message; }
  finally { $('startButton').disabled = !$('videoFile').files[0]; }
});

$('youtubeButton').addEventListener('click', async () => {
  const url = $('youtubeUrl').value.trim();
  if (!url) { $('uploadError').textContent = 'Informe uma URL do YouTube.'; return; }
  $('youtubeButton').disabled = true;
  $('uploadError').textContent = '';
  $('jobPanel').classList.remove('hidden');
  $('resultPanel').classList.add('hidden');
  try {
    $('jobMessage').textContent = 'Obtendo vídeo do YouTube no servidor…';
    const { upload } = await api('/api/youtube', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url }) });
    await submitJob(upload);
  } catch (error) { $('uploadError').textContent = error.message; }
  finally { $('youtubeButton').disabled = false; }
});

async function pollJob(jobId) {
  clearTimeout(pollTimer);
  try {
    const { job } = await api(`/api/jobs/${jobId}`);
    $('jobMessage').textContent = job.message || job.status;
    $('jobStage').textContent = job.stage || job.status;
    $('jobProgressBar').style.width = `${job.progress || 0}%`;
    $('jobProgressText').textContent = `${job.progress || 0}%`;
    if (job.status === 'completed') { await loadResult(jobId); return; }
    if (job.status === 'failed') { $('jobError').textContent = job.message || 'Processamento falhou.'; return; }
    pollTimer = setTimeout(() => pollJob(jobId), 1800);
  } catch (error) { $('jobError').textContent = error.message; }
}

async function loadResult(jobId) {
  const result = await api(`/api/jobs/${jobId}/result`);
  currentResult = result;
  $('resultPanel').classList.remove('hidden');
  $('resultSubtitle').textContent = `${result.source.filename} · análise concluída`;
  $('resultNotes').replaceChildren();
  (result.notes || []).forEach((note) => { const div = document.createElement('div'); div.className = 'notice-item'; div.textContent = note; $('resultNotes').append(div); });
  renderOverview(result);
  renderFrames(result);
  renderAudio(result);
  $('rawTab').replaceChildren(safePre(JSON.stringify(result, null, 2)));
  $('jobMessage').textContent = 'Processamento concluído.';
  $('jobStage').textContent = 'Concluído';
  $('jobProgressBar').style.width = '100%';
  $('jobProgressText').textContent = '100%';
  $('resultPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderOverview(result) {
  const root = $('overviewTab'); root.replaceChildren();
  const player = document.createElement('video'); player.controls = true; player.preload = 'metadata'; player.playsInline = true; player.className = 'video-player'; player.src = `/api/uploads/${encodeURIComponent(result.source.uploadId)}/stream`; root.append(player);
  const info = toolText(result.info);
  let metadata = null;
  try { metadata = JSON.parse(info); metadata = metadata.metadata || metadata; } catch { /* text fallback */ }
  if (metadata) {
    const grid = document.createElement('div'); grid.className = 'metric-grid';
    [['Duração', metadata.duration], ['Resolução', metadata.resolution], ['Codec', metadata.codec], ['FPS original', metadata.original_fps], ['Tamanho', metadata.file_size], ['Áudio', metadata.has_audio ? 'Sim' : 'Não']].forEach(([label, value]) => {
      const card = document.createElement('div'); card.className = 'metric'; const strong = document.createElement('strong'); strong.textContent = String(value ?? '—'); const span = document.createElement('span'); span.textContent = label; card.append(strong, span); grid.append(card);
    }); root.append(grid);
  } else root.append(safePre(info));
  const analysisText = toolText(result.analysis);
  const analysisCard = document.createElement('div'); analysisCard.className = 'data-card'; const heading = document.createElement('h3'); heading.textContent = 'Análise estrutural FFmpeg'; analysisCard.append(heading, safePre(analysisText)); root.append(analysisCard);
  const visualText = textBlock(result.watch?.content, '## OpenAI Visual Analysis');
  if (visualText) { const card = document.createElement('div'); card.className = 'data-card'; const h = document.createElement('h3'); h.textContent = 'Interpretação visual'; card.append(h, safePre(visualText.replace(/^.*## OpenAI Visual Analysis\n/, ''))); root.append(card); }
}

function renderFrames(result) {
  const root = $('framesTab'); root.replaceChildren();
  const images = (result.watch?.content || []).filter((item) => item.type === 'image');
  const descriptions = (result.watch?.content || []).filter((item) => item.type === 'text' && item.text.startsWith('### Frame at '));
  if (!images.length) { root.textContent = 'Nenhum quadro em imagem foi retornado.'; return; }
  const grid = document.createElement('div'); grid.className = 'frame-grid';
  images.forEach((item, index) => {
    const card = document.createElement('div'); card.className = 'frame-card'; const img = document.createElement('img'); img.loading = 'lazy'; img.alt = `Quadro ${index + 1}`; img.src = `data:${item.mimeType || 'image/jpeg'};base64,${item.data}`; const caption = document.createElement('p'); caption.textContent = descriptions[index]?.text.replace('### Frame at ', 'Quadro em ') || `Quadro ${index + 1}`; card.append(img, caption); grid.append(card);
  }); root.append(grid);
}

function renderAudio(result) {
  const root = $('audioTab'); root.replaceChildren();
  const audioText = textBlock(result.watch?.content, '## Audio Analysis');
  const card = document.createElement('div'); card.className = 'data-card'; const h = document.createElement('h3'); h.textContent = 'Transcrição e eventos sonoros'; card.append(h, safePre(audioText || 'Nenhuma análise de áudio retornada.')); root.append(card);
  const timingNote = document.createElement('p'); timingNote.className = 'muted'; timingNote.textContent = 'A disponibilidade e a precisão temporal dependem do backend de áudio configurado. Consulte os avisos da análise para identificar transcrições sem timestamps medidos.'; root.append(timingNote);
}

$('detailButton').addEventListener('click', async () => {
  if (!currentJobId) return;
  $('detailButton').disabled = true;
  $('detailResult').textContent = 'Consultando trecho…';
  try {
    const data = await api(`/api/jobs/${currentJobId}/detail`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ time: $('detailTime').value, duration: 5 }) });
    $('detailResult').replaceChildren(safePre(toolText(data.result)));
    const images = (data.result?.content || []).filter((item) => item.type === 'image');
    const grid = document.createElement('div'); grid.className = 'frame-grid';
    images.forEach((item, index) => { const card = document.createElement('div'); card.className = 'frame-card'; const img = document.createElement('img'); img.src = `data:${item.mimeType || 'image/jpeg'};base64,${item.data}`; img.alt = `Quadro consultado ${index + 1}`; card.append(img); grid.append(card); });
    $('detailResult').append(grid);
  } catch (error) { $('detailResult').textContent = error.message; }
  finally { $('detailButton').disabled = false; }
});

$('resultPanel').addEventListener('click', (event) => {
  const button = event.target.closest('[data-tab]'); if (!button) return;
  document.querySelectorAll('.tab').forEach((tab) => tab.classList.toggle('active', tab === button));
  ['overview', 'frames', 'audio', 'raw'].forEach((name) => $(`${name}Tab`).classList.toggle('hidden', name !== button.dataset.tab));
});

async function loadHistory() {
  try {
    const data = await api('/api/jobs'); const root = $('historyList'); root.replaceChildren();
    if (!data.jobs.length) { root.textContent = 'Nenhuma tarefa recente.'; return; }
    data.jobs.forEach((job) => { const div = document.createElement(job.hasResult ? 'button' : 'div'); div.className = 'history-item'; if (job.hasResult) { div.type = 'button'; div.addEventListener('click', async () => { currentJobId = job.id; await loadResult(job.id); }); } const left = document.createElement('div'); const strong = document.createElement('strong'); strong.textContent = job.summary?.filename || job.id; const small = document.createElement('small'); small.textContent = new Date(job.createdAt).toLocaleString('pt-BR'); left.append(strong, small); const right = document.createElement('span'); right.textContent = `${job.status} · ${job.progress || 0}%`; div.append(left, right); root.append(div); });
  } catch { /* login not active yet */ }
}

(async function init() {
  try { await api('/api/status'); showApp(true); await refreshStatus(); await loadHistory(); }
  catch { showApp(false); }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => undefined);
})();
