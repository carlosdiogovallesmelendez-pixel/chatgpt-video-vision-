# Configuração OpenAI

A configuração é opcional. O programa não contém nem gera chaves de API. O uso da API é cobrado separadamente da assinatura ChatGPT.

## Variáveis

```dotenv
OPENAI_API_KEY=
OPENAI_TRANSCRIPTION_MODEL=gpt-transcribe
OPENAI_AUDIO_EVENTS_MODEL=gpt-audio-1.5
```

Configure esses valores no ambiente do servidor, nunca no navegador.

## Análise visual

`backends/openai-vision.ts` usa `POST /v1/responses`. Envia imagens Base64 extraídas pelo FFmpeg com seus timestamps e solicita um objeto JSON. O modelo padrão é configurável (`gpt-6.1-terra`). O vídeo não é enviado como mídia de vídeo nativa.

A quantidade máxima de quadros é limitada pelo parâmetro/configuração `vision_max_frames`. A amostragem pode deixar de capturar movimentos que ocorram entre quadros.

## Transcrição

`backends/openai.ts` usa `POST /v1/audio/transcriptions` com `gpt-transcribe` por padrão. O limite de upload da API exige que arquivos grandes sejam divididos; a implementação divide WAV de 16 kHz mono em blocos de até oito minutos e limita cada arquivo local a menos de 20 MB.

O modelo moderno retorna texto sem os timestamps granulares de segmento confirmados para `whisper-1`. Nesse caso o adaptador marca `transcription_timing: "unavailable"` e não inventa horários. Definir `OPENAI_TRANSCRIPTION_MODEL=whisper-1` ativa compatibilidade temporária com `verbose_json` e timestamps medidos, enquanto o modelo estiver disponível.

## Eventos sonoros

`backends/openai-audio-events.ts` envia blocos de áudio de até 120 segundos ao modelo indicado por `OPENAI_AUDIO_EVENTS_MODEL`. O adaptador solicita somente eventos não verbais e valida o JSON retornado. É uma implementação experimental: não há garantia de recall/precisão sem ensaios com áudios de referência e uso real da API.

O Gemini original permanece disponível e continua sendo a alternativa de áudio com tags estruturadas implementada no projeto de origem.

## Controle de custo

A análise visual, transcrição e identificação de sons são tarefas separadas. A interface permite desativar tarefas. Reduza FPS, resolução e máximo de quadros para controlar o consumo. O custo real deve ser conferido pelo uso retornado pela API e no painel de faturamento do provedor.

## Documentação oficial

- [Modelos](https://developers.openai.com/api/docs/models)
- [Images and vision](https://developers.openai.com/api/docs/guides/images-vision)
- [Speech to text](https://developers.openai.com/api/docs/guides/speech-to-text)
- [Audio](https://developers.openai.com/api/docs/guides/audio)
- [Responses API](https://developers.openai.com/api/docs/api-reference/responses)
