# Plano e execução de testes

## Testes automatizados do servidor MCP

```bash
npm ci --prefix mcp-server
npm --prefix mcp-server run build
npm --prefix mcp-server test
```

O conjunto original de testes foi mantido. Foram adicionados testes que registram/invocam individualmente os seis handlers com dois vídeos locais de fixture, testes de timestamp sub-segundo e validação de resposta dos adaptadores OpenAI.

## Testes web

Não dependem de pacotes npm externos:

```bash
node --test web/tests/*.test.mjs
```

Incluem sessão HMAC, parser de mensagens JSON-RPC, rejeição de extensões e URLs não permitidas, inicialização HTTP, autenticação, upload e streaming parcial autenticado.

## Testes de processamento local

Os fixtures estão em `mcp-server/tests/fixtures/`. FFmpeg e FFprobe devem estar instalados. A suíte MCP executa o `video_info`, `video_analyze`, `video_watch` e `video_detail` sobre vídeo real de fixture; `video_configure` e `video_setup` são verificados por leitura/persistência e detecção real do ambiente.

## Testes externos

Chamadas reais OpenAI/Gemini exigem credenciais e cobrança externa; não são executadas automaticamente pelos testes unitários. Não se deve classificar mocks como integração real. YouTube exige `yt-dlp` e conectividade externa. Docker exige runtime disponível.

## Relatório da distribuição

Consulte `docs/RELATORIO-FASE-3.md`, que registra os comandos executados e distingue testes aprovados, bloqueados e pendentes.
