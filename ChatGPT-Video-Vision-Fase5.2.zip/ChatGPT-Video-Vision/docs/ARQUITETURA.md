# Arquitetura do ChatGPT Video Vision

## Visão geral

A aplicação é composta por uma interface web estática, um servidor HTTP Node.js e o servidor MCP TypeScript preservado do projeto original.

```text
Chrome / Android PWA
        |
        | HTTPS + cookie de sessão
        v
web/server.mjs (Node HTTP)
        |
        +-- autenticação, upload, quota, fila e persistência
        |
        +-- MCP STDIO bridge (Client + StdioClientTransport do SDK oficial, processo filho)
        |       |
        |       +-- video_watch
        |       +-- video_analyze
        |       +-- video_detail
        |       +-- video_info
        |       +-- video_configure
        |       +-- video_setup
        |       |
        |       +-- FFmpeg / FFprobe / yt-dlp
        |       +-- cache, manifestos e backends de áudio
        |       +-- OpenAI Vision / Transcription / Audio Events
        |       +-- Gemini / Whisper local
        |
        +-- /mcp Streamable HTTP (opcional, token Bearer)
```

A aplicação web não reimplementa os handlers MCP nem constrói mensagens JSON-RPC manualmente. O worker web usa `Client` e `StdioClientTransport` do SDK oficial sobre STDIO para chamar os mesmos seis handlers, garantindo que a lógica de extração, análise, configuração e consulta permaneça centralizada. O servidor também oferece o transporte oficial Streamable HTTP com mapa de sessões mantido no callback `onsessioninitialized`.

## Processamento de uma tarefa web

1. O navegador envia o vídeo por `POST /api/upload` ou solicita a obtenção de um vídeo público do YouTube por `POST /api/youtube`.
2. O servidor cria um identificador interno aleatório e armazena o arquivo em diretório privado.
3. `POST /api/jobs` cria uma tarefa persistente.
4. Um worker serial processa a fila: `video_configure`, `video_info`, `video_analyze` e `video_watch`.
5. O resultado é persistido em JSON privado, e o navegador acompanha o estado por polling autenticado.
6. A consulta de momento específico invoca `video_detail` no mesmo servidor MCP.

A fila web processa uma tarefa por vez por processo. Tarefas que estavam em andamento quando o servidor reinicia são marcadas como interrompidas; não são retomadas silenciosamente.

## Adaptadores externos

- `backends/openai-vision.ts`: envia imagens extraídas, com timestamps, ao endpoint Responses. Não envia MP4 como vídeo nativo.
- `backends/openai.ts`: transcrição por `gpt-transcribe`; `whisper-1` é compatibilidade temporária para segmentos temporizados. Arquivos WAV grandes são divididos antes de upload.
- `backends/openai-audio-events.ts`: implementação opcional de classificação de sons com GPT-Audio. É experimental e precisa de credencial e chamada real para comprovar funcionamento e qualidade.
- `backends/gemini-api.ts`: backend original preservado para transcrição e tags de áudio.
- `backends/local.ts`: Whisper local preservado.

## Caminhos de dados

`VIDEO_VISION_HOME` controla armazenamento/configuração. Por padrão, sem variável, o diretório antigo `~/.claude-video-vision` é reutilizado para compatibilidade. Em container, o valor recomendado é `/app/storage`.

Diretórios são criados em modo restrito pelo processo. A interface não serve arquivos diretamente da pasta de armazenamento; o vídeo é entregue por rota autenticada com suporte a HTTP Range.

## Limitações arquiteturais conhecidas

- Não há banco de dados multiusuário; a primeira versão é uma aplicação de instância única com credencial administrativa compartilhada.
- A fila é persistida em arquivos JSON, mas é de processo único. Não se deve escalar várias réplicas sem migrar a fila e o armazenamento para serviços compartilhados.
- O transporte MCP remoto é opcional e exige `MCP_AUTH_TOKEN` forte. O acesso web no Android não depende dele.
- A interface PWA é vanilla HTML/CSS/JS para reduzir dependências. Não depende de React ou Vite.
- Upload retomável em partes ainda não foi implementado; a transferência única pode precisar ser repetida após uma interrupção.
