# Uso no Android / Chrome

A interface é servida pelo backend e pode ser aberta no Chrome do Android. O telefone funciona como cliente web; FFmpeg, FFprobe, yt-dlp, Node.js, Python, Whisper e chamadas de API executam no servidor.

## Fluxo

1. Abra o endereço HTTPS fornecido pelo administrador.
2. Entre com o usuário e a senha definidos no ambiente do servidor.
3. Escolha um vídeo na galeria do Android ou informe uma URL HTTPS de um vídeo individual do YouTube.
4. Configure modelo visual, resolução, FPS, quantidade máxima de quadros e backend de áudio.
5. Inicie a análise e acompanhe as etapas na tela.
6. Consulte visão geral, quadros, áudio e dados estruturados.
7. Use a consulta de momento com horário `HH:MM:SS` ou `HH:MM:SS.mmm`.

## PWA

A aplicação publica um manifesto e um service worker para que navegadores compatíveis possam adicioná-la à tela inicial. A instalação é opcional; abrir o endereço no navegador é suficiente.

## Limitações

- O upload atual é uma transferência HTTP única, não retomável em blocos. Se a conexão cair, envie o arquivo novamente.
- O servidor não mantém o navegador acordado. Depois de enviar uma tarefa, o processamento continua no servidor, mas o navegador pode suspender a tela em segundo plano; ao voltar, consulte o histórico.
- Um teste real em um Moto G04 físico não foi realizado nesta distribuição. A compatibilidade deve ser confirmada no aparelho e na versão do Chrome utilizados.
- Arquivos muito grandes dependem dos limites configurados na hospedagem, memória, disco e tempo de conexão.
