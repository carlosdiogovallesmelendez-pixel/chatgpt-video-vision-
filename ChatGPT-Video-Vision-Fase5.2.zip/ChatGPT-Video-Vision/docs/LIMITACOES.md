# Limitações conhecidas

1. **Build nesta sessão:** o ambiente fornecido tinha Node.js 22.16.0, mas o projeto declara Node.js >=24. A tentativa de instalar dependências falhou porque o ambiente não resolveu o DNS do npm registry (`EAI_AGAIN`). O build TypeScript e os testes Vitest não podem ser considerados aprovados aqui.
2. **APIs OpenAI/Gemini:** nenhuma credencial real foi fornecida ou utilizada. Os adaptadores foram implementados, mas não foram validados por chamadas reais nesta distribuição.
3. **GPT-Transcribe timestamps:** o adaptador marca os tempos como indisponíveis quando o modelo não os fornece. `whisper-1` é opção temporária para segmentos medidos.
4. **GPT-Audio eventos:** implementação experimental; classificação e qualidade ainda não foram comparadas em teste real com Gemini.
5. **YouTube:** o código de download foi preparado com yt-dlp, mas yt-dlp não estava disponível no ambiente desta sessão. Vídeos privados, protegidos, indisponíveis ou com restrições podem falhar.
6. **Moto G04 físico:** não foi realizado teste no aparelho físico. Os testes de interface executados são testes HTTP/estáticos, não certificação Android.
7. **Docker:** Docker/Podman não estavam disponíveis para executar um build real de container nesta sessão.
8. **Escala:** fila em memória de processo único com estado persistido em JSON; não é uma arquitetura multi-instância. Não escale horizontalmente sem substituir a fila e o armazenamento por serviços compartilhados.
9. **Upload retomável:** o upload web atual é uma requisição única com progresso; não implementa retomada de blocos depois de interrupção.
10. **Segurança de rede:** o aplicativo inclui autenticação, validação de URL e controles locais, mas ainda exige HTTPS, firewall/reverse proxy confiável, atualização contínua e revisão de segurança antes de exposição pública.
11. **Movimento visual:** a interpretação compara quadros amostrados, não assiste a um fluxo contínuo. Eventos rápidos entre quadros podem não ser detectados.
