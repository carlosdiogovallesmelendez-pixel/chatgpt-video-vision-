# Testes oficiais do MCP

Esta suíte usa somente o SDK oficial `@modelcontextprotocol/sdk`; não substitui o transporte por JSON-RPC manual.

## Requisitos

- Node.js >=24 (Node 24 LTS ou 26).
- `npm ci --prefix mcp-server` concluído.
- FFmpeg e FFprobe no PATH.
- Nenhuma chave OpenAI/Gemini necessária.

## Execução

Na raiz:

```bash
npm ci --prefix mcp-server
npm run build
npm --prefix mcp-server test
npm --prefix mcp-server run test:stdio
npm run test:web
```

`test:stdio` usa `Client` e `StdioClientTransport` do SDK, inicia o `dist/index.js`, executa `initialize`, `tools/list` e `tools/call` para as seis ferramentas. O fixture é criado com FFmpeg: vídeo `testsrc2` e áudio senoidal, sem credenciais externas.

A suíte `web/tests/mcp-integration.test.mjs` inicia a aplicação HTTP real, autentica, faz upload, cria uma tarefa sem IA externa, acompanha o worker, lê o resultado, consulta um instante, verifica histórico, usa o SDK oficial sobre STDIO e testa duas chamadas na mesma sessão Streamable HTTP.

O teste é marcado como `SKIP` quando Node, build ou SDK não estão presentes; esse status não equivale a aprovação.
