# Atribuição e licença

Esta adaptação deriva do projeto **Claude Video Vision**, de Jordan Vasconcelos, originalmente publicado em:

https://github.com/jordanrendric/claude-video-vision

O arquivo `LICENSE` original foi preservado sem substituição. O código original reaproveitado mantém seus avisos de copyright conforme a licença MIT. Arquivos específicos de integração Claude Code foram preservados em `legacy/claude-code/`.

As alterações desta adaptação são identificadas no `CHANGELOG.md` e neste pacote. OpenAI, ChatGPT, Google, Gemini, FFmpeg e outras marcas pertencem aos respectivos titulares. Este projeto é independente e não é produto oficial, endossado ou operado pela OpenAI.
