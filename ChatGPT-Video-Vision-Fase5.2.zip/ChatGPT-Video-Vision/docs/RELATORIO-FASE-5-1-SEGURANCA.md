# Relatório de segurança e preparação — Fase 5.1

Data: 2026-11-07
Base: `ChatGPT-Video-Vision-Fase4.zip`

## Resumo executivo

A preparação foi feita localmente. Nenhum repositório foi criado, nenhuma conta acessada, nenhum arquivo enviado, nenhum workflow executado no GitHub, nenhuma credencial solicitada e nenhuma cobrança/serviço contratado.

Foi mantido um único workflow ativo de CI, com execução automática em `push`/`pull_request` para `main` e execução manual por `workflow_dispatch`. O CI usa Node.js 24 e 26, FFmpeg/FFprobe, dependências npm travadas e os testes MCP/web existentes.

## Auditoria dos arquivos YAML

| Arquivo | Tipo | Resultado |
|---|---|---|
| `.github/workflows/ci.yml` | Workflow ativo | Ajustado; apenas leitura do conteúdo do repositório |
| `.github/workflows/release.yml` | Workflow manual antigo | Removido; criava ZIP do código e fazia upload como artifact |
| `.github/dependabot.yml` | Automação de atualizações | Removido para evitar PRs automáticos antes de autorização |
| `.github/ISSUE_TEMPLATE/bug_report.yml` | Formulário | Sem comandos de execução |
| `.github/ISSUE_TEMPLATE/feature_request.yml` | Formulário | Sem comandos de execução |
| `.github/FUNDING.yml` | Links de patrocínio | Metadados, sem execução de código |
| `docker-compose.yml` | Configuração local | Não é workflow; só executa quando o usuário chama Docker Compose |
| `legacy/original-workflows/release-publish-original.yml` | Arquivo histórico fora de `.github/workflows` | Não é workflow ativo; contém instruções antigas de publicação npm |

Todos os arquivos YAML ativos e auxiliares sob `.github` foram analisados sintaticamente. O único workflow restante está em `.github/workflows/ci.yml`.

## Permissões do CI

O workflow tem somente:

```yaml
permissions:
  contents: read
```

Também usa `persist-credentials: false` em `actions/checkout`. Não solicita permissões para publicar pacotes, criar releases, escrever no repositório, implantar, emitir attestations ou usar OIDC. Não usa `secrets.*`.

O cache npm do `setup-node` foi desativado. O CI ainda precisa baixar o próprio repositório, as actions e pacotes npm para o runner do GitHub quando for iniciado pelo proprietário; isso é inerente ao serviço e não ocorre nesta preparação local.

## Auditoria de scripts npm

Scripts da raiz:
- `build`: chama o build do servidor MCP;
- `test`: build, Vitest, teste STDIO oficial e testes web;
- `test:web`: Node test runner;
- `start`, `start:mcp`, `dev`: comandos de execução manual, não chamados pelo CI.

Scripts de `mcp-server`:
- `prebuild` e `pretest`/`pretest:stdio`: verificam Node.js >=24;
- `build`: executa `tsc` e ajusta permissão do executável gerado;
- `test`: `vitest run`;
- `test:stdio`: inicia o servidor MCP e testa com cliente SDK oficial;
- `prepublishOnly`: build e testes, mas não é chamado pelo CI;
- `test:gemini`: teste opcional que pode acessar Gemini quando executado manualmente com credencial; não é chamado pelo CI;
- `measure`: ferramenta local, não chamada pelo CI.

`npm ci` pode executar lifecycle scripts declarados por dependências de terceiros. O lockfile fixa versões e URLs `registry.npmjs.org`, e o workflow não fornece chaves API nem tokens npm ao processo. Não foi possível auditar dinamicamente scripts de instalação transitivos porque não houve instalação npm nesta etapa; isso deve ser considerado risco residual normal de dependências externas.

## Credenciais e dados sensíveis

Foi feita varredura textual por padrões comuns de chaves OpenAI, Google API, tokens GitHub e cabeçalhos de chave privada. Nenhuma correspondência foi encontrada no conteúdo atual do ZIP. Essa varredura não é prova criptográfica e não examina histórico Git anterior, porque o ZIP não contém histórico `.git`.

`.env.example` contém somente placeholders. Foi corrigido `.gitignore`, pois antes `.env.*` também ignorava `.env.example`; agora o exemplo fica elegível para envio e os arquivos `.env` reais continuam ignorados.

O workflow de CI não chama OpenAI nem Gemini. Os testes MCP limpam variáveis `OPENAI_API_KEY`, `GEMINI_API_KEY` e `MCP_AUTH_TOKEN` do ambiente do processo MCP filho.

## Dependências e ações externas

- Actions: `actions/checkout@v7` e `actions/setup-node@v7`, versões oficiais atuais consultadas na documentação/release do GitHub.
- Runner instala FFmpeg via `apt-get` (Ubuntu) ou `brew` (macOS).
- `npm ci` baixa pacotes conforme `mcp-server/package-lock.json`, com URLs do registro npm.
- Não há actions de deploy, publicação, release ou upload de artifacts.

Risco residual: as actions estão referenciadas por tags principais (`@v7`), não por SHA completo imutável. Isso é prático e compatível com a documentação oficial, mas fixar SHA completo é a proteção mais forte contra alteração de tag. Não inventei SHA completo sem confirmação verificável; uma futura revisão pode fixá-los após conferir os commits oficiais.

## Alterações realizadas

1. Adicionado `workflow_dispatch` ao CI.
2. Preservados os eventos `push` e `pull_request` para `main`.
3. Mantida a matriz Node.js 24 e 26 em Ubuntu e macOS.
4. Mantida a permissão mínima `contents: read`.
5. Desativada a persistência de credenciais do checkout.
6. Desativado cache npm.
7. Adicionada verificação de versões Node/npm/FFmpeg/FFprobe antes da instalação.
8. Removido workflow que fazia upload do ZIP do código como artifact.
9. Removida configuração Dependabot para impedir PRs automáticos antes da autorização.
10. Corrigida exceção do `.env.example` no `.gitignore`.
11. Adicionada documentação de operação segura em `docs/GITHUB_ACTIONS_SEGURO.md`.
12. Preservados os seis handlers originais, sem alterações.

## Testes desta preparação

- Parse dos YAML: aprovado para todos os YAML sob `.github` e para o workflow ativo.
- Varredura textual de segredos conhecidos: nenhuma correspondência encontrada.
- Regras `.gitignore`: `.env.example` não é ignorado; `.env` e `.env.production` são ignorados.
- `node --test web/tests/*.test.mjs`: 4 passaram, 0 falharam, 1 foi pulado por exigir Node 24, build MCP e SDK instalado.
- Build MCP e execução oficial do protocolo: não executados nesta fase, pois não foi instalado Node 24 nem dependências.

## Estado e autorização

O pacote está preparado, mas nada foi enviado ao GitHub. A execução real só começará quando o proprietário criar o repositório privado, enviar a estrutura extraída e iniciar manualmente o workflow CI.
