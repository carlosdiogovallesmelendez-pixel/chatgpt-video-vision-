# Instalação

## Requisitos

- Node.js 24 ou superior.
- npm compatível.
- FFmpeg e FFprobe no `PATH`.
- yt-dlp opcional para YouTube.
- Espaço persistente suficiente para vídeos, quadros, áudio temporário e resultados.

## Execução sem Docker

1. Extraia o ZIP.
2. Instale Node.js 24+ e FFmpeg/FFprobe no computador ou servidor de processamento.
3. Copie `.env.example` para `.env`.
4. Substitua os exemplos por credenciais próprias. `APP_PASSWORD` deve ter ao menos 12 caracteres; `SESSION_SECRET`, ao menos 32 caracteres. Remova `CHANGE_ME`.
5. Instale e compile o servidor MCP:

   ```bash
   npm ci --prefix mcp-server
   npm --prefix mcp-server run build
   ```

6. Exporte as variáveis de ambiente no processo. Node.js não carrega `.env` automaticamente. Em um shell POSIX:

   ```bash
   set -a
   . ./.env
   set +a
   ```

7. Inicie:

   ```bash
   node web/server.mjs
   ```

8. Acesse `http://localhost:8080`. Para acesso remoto, utilize HTTPS por meio de proxy confiável.

## Docker Compose

```bash
cp .env.example .env
# Edite .env e troque todos os valores de exemplo.
docker compose up --build -d
```

O container usa Node 24, instala FFmpeg/FFprobe e yt-dlp, compila o servidor MCP e executa a aplicação sem privilégios de root. O volume `video-vision-storage` persiste o diretório `/app/storage`.

## Sem credenciais externas

A aplicação ainda permite login, leitura de metadados, extração de quadros e análise estrutural com FFmpeg. Transcrição e interpretação visual por API serão omitidas ou gerarão avisos até que o provedor correspondente seja configurado. Não são criadas chaves automaticamente.

## Configurações de ambiente

Consulte `.env.example`. As chaves de API são lidas apenas pelo servidor. Nunca coloque chaves em arquivos dentro de `web/public/`.
