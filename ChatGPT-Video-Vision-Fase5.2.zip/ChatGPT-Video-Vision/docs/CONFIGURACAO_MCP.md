# Configuração MCP

## STDIO local

Depois de instalar dependências e compilar com Node.js 24+:

```bash
npm ci --prefix mcp-server
npm --prefix mcp-server run build
npm --prefix mcp-server start
```

O servidor registra os nomes originais: `video_watch`, `video_analyze`, `video_detail`, `video_info`, `video_configure` e `video_setup`.

A configuração de armazenamento pode ser apontada com `VIDEO_VISION_HOME`. Sem ela, o caminho antigo `~/.claude-video-vision` é reutilizado para compatibilidade.

## MCP remoto HTTP

O endpoint opcional é `/mcp`, usando Streamable HTTP do SDK MCP. Para ativá-lo, configure `MCP_AUTH_TOKEN` com valor aleatório forte de pelo menos 24 caracteres. Sem token válido, a rota permanece desativada.

O endpoint remoto só deve ser exposto através de HTTPS, rate limiting e controles de rede do host. A primeira versão limita sessões simultâneas e expira sessões inativas. O token é um segredo de servidor e nunca deve ser enviado ao browser.

A conexão MCP remota não é necessária para a interface web e não implica que o aplicativo móvel ChatGPT possa iniciar servidores locais.
