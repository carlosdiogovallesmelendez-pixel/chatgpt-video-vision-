# Preparação segura do GitHub Actions — Fase 5.1

## O que este repositório faz no CI

O workflow `.github/workflows/ci.yml` pode iniciar por:
- `push` na branch `main`;
- `pull_request` direcionado à `main`;
- `workflow_dispatch` (execução manual pela aba Actions).

A matriz mantém Node.js 24 e 26 em Ubuntu e macOS. Instala FFmpeg/FFprobe, executa `npm ci`, compila o servidor MCP, roda Vitest, executa o teste MCP oficial por STDIO e os testes web.

## Permissões e privacidade

O workflow declara somente `permissions: contents: read`.
- Não tem `contents: write`, `packages: write`, `id-token: write`, `deployments: write` ou permissões de publicação.
- `actions/checkout` usa `persist-credentials: false`, para não deixar o token do checkout disponível ao código de teste após a etapa.
- O cache npm foi desativado; isso evita persistir/recuperar cache de dependências entre execuções.
- Não há `secrets.*`, chaves OpenAI/Gemini, login npm, `npm publish`, criação de release, deploy ou upload de artefatos no workflow de CI.
- Os testes MCP limpam `OPENAI_API_KEY`, `GEMINI_API_KEY` e `MCP_AUTH_TOKEN` do ambiente do processo filho.
- Os testes usam vídeos de fixture e credenciais de teste locais, não credenciais reais.

O workflow precisa baixar código do repositório e dependências npm e instalar ações oficiais do GitHub. Isso significa que, após o usuário iniciar o CI, o código e os manifests ficam disponíveis ao runner GitHub, e o runner acessa o registro npm e os repositórios das Actions. Não há envio para serviços de IA.

## Instalação npm e scripts

Comandos executados pelo CI:
1. `npm ci` em `mcp-server`;
2. `npm run build` em `mcp-server`;
3. `npm test` em `mcp-server`;
4. `npm run test:stdio` em `mcp-server`;
5. `npm run test:web` na raiz.

Scripts npm/lifecycle relevantes:
- `prebuild`: verifica Node.js >=24;
- `build`: executa `tsc` e `chmod +x dist/index.js`;
- `pretest`: verifica Node.js >=24;
- `test`: `vitest run`;
- `pretest:stdio`: verifica Node.js >=24;
- `test:stdio`: inicia o servidor MCP filho e usa o cliente SDK oficial;
- `prepublishOnly`: build + testes, mas não é chamado pelo CI;
- `test:gemini`: script opcional que poderia chamar Gemini se invocado manualmente com `GEMINI_API_KEY`; não é chamado pelo workflow;
- `measure`: ferramenta local de medição, não é chamada pelo workflow.

`npm ci` pode executar scripts de instalação declarados por dependências de terceiros. O lockfile fixa as versões e URLs do registro npm. O CI não fornece segredos ao processo npm. A revisão estática do repositório não substitui uma auditoria de cada pacote transitivo e seus scripts de instalação.

## Alterações de segurança desta preparação

- Adicionado `workflow_dispatch` ao workflow de CI.
- Mantidos Node.js 24 e 26.
- Desativado cache npm do `setup-node`.
- Desativada persistência de credenciais do checkout.
- Mantidas apenas permissões `contents: read`.
- Removido `.github/workflows/release.yml`, que criava um ZIP da árvore do repositório e fazia upload como artifact do GitHub Actions. Isso não era necessário para validar o MCP e transferia o código para o armazenamento de artifacts.
- Removido `.github/dependabot.yml` nesta preparação para evitar que o GitHub abra automaticamente pull requests de atualização antes da autorização do proprietário. A configuração pode ser reintroduzida depois.
- Corrigido `.gitignore` para permitir `.env.example`, mantendo `.env` e os demais `.env.*` ignorados.

## Arquivos que não são workflows ativos

`legacy/original-workflows/release-publish-original.yml` é um arquivo histórico fora de `.github/workflows`. O GitHub Actions não o executa nesse local. Ele contém uma antiga receita de publicação npm com `contents: write`, `id-token: write` e `npm publish --provenance --access public`. Não mova nem copie esse arquivo para `.github/workflows` sem uma revisão específica. O arquivo foi preservado para histórico, mas não está ativo.

## Antes de enviar ao GitHub

1. Crie um repositório **Private**.
2. Não adicione secrets de API.
3. Envie a pasta extraída do projeto, incluindo `.github/workflows/ci.yml`.
4. Confirme que `.env.example` está incluído e que `.env` real não está.
5. Na aba **Actions**, selecione **CI** e escolha **Run workflow**.
6. Escolha a branch `main` e inicie a execução manual.

A execução de CI usa minutos de GitHub Actions. Verifique a franquia/limites do seu plano e configure limites de gastos nas configurações de Billing antes de executar. Não é necessário habilitar cobrança para iniciar uma execução dentro da franquia disponível; excedentes dependem do plano e das configurações.

## Comandos de verificação após clonar o repositório

```bash
node --version
npm --version
ffmpeg -version
ffprobe -version

cd mcp-server
npm ci
npm run build
npm test
npm run test:stdio
cd ..
npm run test:web
```

A aprovação oficial só existe se o log do Actions mostrar build e testes MCP/Web executados e aprovados. Um workflow configurado, por si só, não é evidência de execução.
